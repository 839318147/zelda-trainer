// 塞尔达传说：旷野之息（Savage Wind Recomp）修改器
// 外部内存修改器：附加到 savagewind.exe，读写游戏映射的客户机内存（游戏把内存映射在自己的地址上）。
// 单机使用；只改内存，不写存档。
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

static class Ui
{
    public static float S = 1f;
}

static class Native
{
    [DllImport("user32.dll")]
    public static extern uint GetDpiForWindow(IntPtr hwnd);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool ReadProcessMemory(IntPtr h, IntPtr addr, byte[] buf, IntPtr size, out IntPtr read);
    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool WriteProcessMemory(IntPtr h, IntPtr addr, byte[] buf, IntPtr size, out IntPtr written);
    [DllImport("kernel32.dll")]
    public static extern bool CloseHandle(IntPtr h);
    [DllImport("user32.dll")]
    public static extern bool RegisterHotKey(IntPtr hwnd, int id, uint mods, uint vk);
    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);
}

// Xbox 手柄支持（键盘的 GetAsyncKeyState 读不到手柄按键）
static class Pad
{
    [StructLayout(LayoutKind.Sequential)]
    public struct Gamepad
    {
        public ushort Buttons;
        public byte LeftTrigger;
        public byte RightTrigger;
        public short LeftX;
        public short LeftY;
        public short RightX;
        public short RightY;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct State
    {
        public uint Packet;
        public Gamepad Pad;
    }

    [DllImport("xinput1_4.dll", EntryPoint = "XInputGetState")]
    private static extern uint GetState14(uint index, out State state);
    [DllImport("xinput9_1_0.dll", EntryPoint = "XInputGetState")]
    private static extern uint GetState910(uint index, out State state);

    private static bool use14 = true;
    private static bool probed;

    public static bool Query(uint index, out State s)
    {
        s = default(State);
        if (!probed)
        {
            probed = true;
            State tmp;
            try { GetState14(0, out tmp); } catch { use14 = false; }
        }
        try { return (use14 ? GetState14(index, out s) : GetState910(index, out s)) == 0; }
        catch { return false; }
    }

    // 手柄 Y 键（XInput 里是 0x8000）
    public static bool JumpHeld()
    {
        for (uint i = 0; i < 4; i++)
        {
            State s;
            if (!Query(i, out s)) continue;
            if ((s.Pad.Buttons & 0x8000) != 0) return true;
        }
        return false;
    }
}

// 游戏内存布局（Savage Wind Recomp，游戏版本 1.9.0 / 1.8.2）
static class Game
{
    const ulong PIF_190 = 0x7001e13ed0;
    const ulong PIF_182 = 0x7001cb2658;
    const ulong WM_190 = 0x7001e57580;
    const ulong WM_182 = 0x7001cf5d00;

    const ulong OFF_PIF_PLAYER = 0x60;
    const ulong OFF_PIF_MAXHEART = 0xA0;
    const ulong OFF_PIF_STAMINA_CURMAX = 0xA4;
    const ulong OFF_PL_LIFE = 0x848;
    const ulong OFF_PL_MAXLIFE = 0x1868;
    const ulong OFF_WM_COUNT = 0x5C0;
    const ulong OFF_WM_MANAGERS = 0x5C8;
    const ulong OFF_TOD = 0xB8;

    public const int MAX_HEART_QUARTERS = 120; // 30 颗心（游戏上限）

    // 实时 GameData（1.9.0 实测地址；运行时校验类型常量 0x7001D21358）
    public const ulong GD_RUPEE = 0x724E31D000;
    public const ulong GD_POUCH = 0x724E3325C0;  // PorchItem_Value1[0]，步长 0x18
    public const ulong GD_STRIDE = 0x18;
    public const ulong GD_TYPE = 0x7001D21358;
    public const ulong GD_STAMINA = 0x724E32B6A8; // 当前体力（f32，0..上限，1000 = 一圈）
    public const ulong GD_NAMES = 0x724E33E2C0;      // PorchItem 名字数组，条目 0x68 字节，名字在 +0x2C（64 字节缓冲）
    public const ulong GD_NAME_STRIDE = 0x68;
    public const ulong GD_NAME_TYPE = 0x7001D215B0;  // 名字条目 +0x08 的类型标记
    public static ulong[] PouchValues = new ulong[420];
    public static int[] ArrowSlots = new int[3];
    public static int[] WeaponSlots = new int[0];
    public static byte[][] WeaponNames = new byte[0][];
    public static ulong[] WeaponValues = new ulong[0];
    public static string GdSlot = "";
    public static bool GdReady;

    // 可选物品清单（分类\tActor名\t中文名），来自游戏内中文 message（Msg_CNzh）
    public static string[] ItemData = new string[]
    {
        "箭矢	AncientArrow	古代兵装·箭",
        "箭矢	BombArrow_A	炸弹箭",
        "箭矢	ElectricArrow	电箭",
        "箭矢	FireArrow	火箭",
        "箭矢	IceArrow	冰箭",
        "箭矢	NormalArrow	木箭",
        "武器	Weapon_Lsword_001	旅人双手剑",
        "武器	Weapon_Lsword_002	士兵双手剑",
        "武器	Weapon_Lsword_003	骑士双手剑",
        "武器	Weapon_Lsword_004	波克棍",
        "武器	Weapon_Lsword_005	尖刺波克棍",
        "武器	Weapon_Lsword_006	龙骨波克棍",
        "武器	Weapon_Lsword_010	莫力布林棍",
        "武器	Weapon_Lsword_011	尖刺莫力布林棍",
        "武器	Weapon_Lsword_012	龙骨莫力布林棍",
        "武器	Weapon_Lsword_013	守护者之斧",
        "武器	Weapon_Lsword_014	守护者之斧+",
        "武器	Weapon_Lsword_015	守护者之斧++",
        "武器	Weapon_Lsword_016	莱尼尔大剑",
        "武器	Weapon_Lsword_017	兽王大剑",
        "武器	Weapon_Lsword_018	兽神大剑",
        "武器	Weapon_Lsword_019	莫力布林之骨",
        "武器	Weapon_Lsword_023	古代兵装·大剑",
        "武器	Weapon_Lsword_024	王族双手剑",
        "武器	Weapon_Lsword_027	卓拉大剑",
        "武器	Weapon_Lsword_029	格鲁德双手剑",
        "武器	Weapon_Lsword_030	达人斧头",
        "武器	Weapon_Lsword_031	铁锤",
        "武器	Weapon_Lsword_032	樵夫斧头",
        "武器	Weapon_Lsword_033	火焰大剑",
        "武器	Weapon_Lsword_034	冰雪大剑",
        "武器	Weapon_Lsword_035	雷电大剑",
        "武器	Weapon_Lsword_036	劈石剑",
        "武器	Weapon_Lsword_037	碎岩剑",
        "武器	Weapon_Lsword_038	船桨",
        "武器	Weapon_Lsword_041	戒心长刀",
        "武器	Weapon_Lsword_045	农用锄头",
        "武器	Weapon_Lsword_047	近卫双手剑",
        "武器	Weapon_Lsword_051	大飞旋镖",
        "武器	Weapon_Lsword_054	碎岩巨剑",
        "武器	Weapon_Lsword_055	静心大剑",
        "武器	Weapon_Lsword_056	克洛格的团扇",
        "武器	Weapon_Lsword_057	六贤者之剑",
        "武器	Weapon_Lsword_059	大鼓隆之剑",
        "武器	Weapon_Lsword_060	鬼神大剑",
        "武器	Weapon_Lsword_074	斩风刀",
        "武器	Weapon_Spear_001	旅人之枪",
        "武器	Weapon_Spear_002	士兵之枪",
        "武器	Weapon_Spear_003	骑士之枪",
        "武器	Weapon_Spear_004	波克枪",
        "武器	Weapon_Spear_005	尖刺波克枪",
        "武器	Weapon_Spear_006	龙骨波克枪",
        "武器	Weapon_Spear_007	蜥蜴枪",
        "武器	Weapon_Spear_008	强力蜥蜴枪",
        "武器	Weapon_Spear_009	双头蜥蜴枪",
        "武器	Weapon_Spear_010	莫力布林枪",
        "武器	Weapon_Spear_011	尖刺莫力布林枪",
        "武器	Weapon_Spear_013	守护者之枪",
        "武器	Weapon_Spear_014	守护者之枪+",
        "武器	Weapon_Spear_015	守护者之枪++",
        "武器	Weapon_Spear_016	莱尼尔之枪",
        "武器	Weapon_Spear_017	兽王枪",
        "武器	Weapon_Spear_018	兽神枪",
        "武器	Weapon_Spear_021	生锈的枪",
        "武器	Weapon_Spear_022	农用钉耙",
        "武器	Weapon_Spear_023	古代兵装·枪",
        "武器	Weapon_Spear_024	王族之枪",
        "武器	Weapon_Spear_025	森民之枪",
        "武器	Weapon_Spear_027	卓拉之枪",
        "武器	Weapon_Spear_028	银鳞之枪",
        "武器	Weapon_Spear_029	格鲁德之枪",
        "武器	Weapon_Spear_030	投枪",
        "武器	Weapon_Spear_031	削岩棒",
        "武器	Weapon_Spear_032	斩风羽枪",
        "武器	Weapon_Spear_033	火焰枪",
        "武器	Weapon_Spear_034	冰雪枪",
        "武器	Weapon_Spear_035	雷电枪",
        "武器	Weapon_Spear_036	木拖把",
        "武器	Weapon_Spear_037	蜿蜒之枪",
        "武器	Weapon_Spear_038	渔夫的鱼叉",
        "武器	Weapon_Spear_047	近卫之枪",
        "武器	Weapon_Spear_049	祭祀之枪",
        "武器	Weapon_Spear_050	光鳞之枪",
        "武器	Weapon_Sword_001	旅人之剑",
        "武器	Weapon_Sword_002	士兵之剑",
        "武器	Weapon_Sword_003	骑士之剑",
        "武器	Weapon_Sword_004	波克棒",
        "武器	Weapon_Sword_005	尖刺波克棒",
        "武器	Weapon_Sword_006	龙骨波克棒",
        "武器	Weapon_Sword_007	蜥蜴飞旋镖",
        "武器	Weapon_Sword_008	强力蜥蜴飞旋镖",
        "武器	Weapon_Sword_009	三叉蜥蜴飞旋镖",
        "武器	Weapon_Sword_013	守护者匕首",
        "武器	Weapon_Sword_014	守护者匕首+",
        "武器	Weapon_Sword_015	守护者匕首++",
        "武器	Weapon_Sword_016	莱尼尔之剑",
        "武器	Weapon_Sword_017	兽王剑",
        "武器	Weapon_Sword_018	兽神剑",
        "武器	Weapon_Sword_019	波克布林之骨",
        "武器	Weapon_Sword_020	蜥蜴战士之骨",
        "武器	Weapon_Sword_021	生锈的剑",
        "武器	Weapon_Sword_022	木汤勺",
        "武器	Weapon_Sword_023	古代兵装·剑",
        "武器	Weapon_Sword_024	王族之剑",
        "武器	Weapon_Sword_025	森民之剑",
        "武器	Weapon_Sword_027	卓拉之剑",
        "武器	Weapon_Sword_029	格鲁德匕首",
        "武器	Weapon_Sword_030	月光匕首",
        "武器	Weapon_Sword_031	斩风羽剑",
        "武器	Weapon_Sword_033	火焰剑",
        "武器	Weapon_Sword_034	冰雪剑",
        "武器	Weapon_Sword_035	雷电剑",
        "武器	Weapon_Sword_040	弹簧锤",
        "武器	Weapon_Sword_041	戒心小刀",
        "武器	Weapon_Sword_043	火把",
        "武器	Weapon_Sword_044	木枝",
        "武器	Weapon_Sword_047	近卫之剑",
        "武器	Weapon_Sword_048	陨石杖",
        "武器	Weapon_Sword_049	冰冻杖",
        "武器	Weapon_Sword_050	雷电杖",
        "武器	Weapon_Sword_051	飞旋镖",
        "武器	Weapon_Sword_052	七宝匕首",
        "武器	Weapon_Sword_053	夺命镰刀",
        "武器	Weapon_Sword_057	女神的白刃剑",
        "武器	Weapon_Sword_058	长剑",
        "武器	Weapon_Sword_059	海风飞旋镖",
        "武器	Weapon_Sword_060	火焰杖",
        "武器	Weapon_Sword_061	冰雪杖",
        "武器	Weapon_Sword_062	电击杖",
        "武器	Weapon_Sword_070	大师之剑",
        "武器	Weapon_Sword_073	恶魔圆刃",
        "武器	Weapon_Sword_080	大师之剑",
        "武器	Weapon_Sword_081	大师之剑",
        "武器	Weapon_Sword_502	必杀之剑",
        "弓	Weapon_Bow_001	旅人之弓",
        "弓	Weapon_Bow_002	士兵之弓",
        "弓	Weapon_Bow_003	尖刺波克弓",
        "弓	Weapon_Bow_004	波克弓",
        "弓	Weapon_Bow_006	蜥蜴弓",
        "弓	Weapon_Bow_009	莱尼尔之弓",
        "弓	Weapon_Bow_011	强力蜥蜴弓",
        "弓	Weapon_Bow_013	森民之弓",
        "弓	Weapon_Bow_014	卓拉之弓",
        "弓	Weapon_Bow_015	格鲁德之弓",
        "弓	Weapon_Bow_016	飞燕弓",
        "弓	Weapon_Bow_017	游隼弓",
        "弓	Weapon_Bow_023	古代兵装·弓",
        "弓	Weapon_Bow_026	兽王弓",
        "弓	Weapon_Bow_027	龙骨波克弓",
        "弓	Weapon_Bow_028	大鹫弓",
        "弓	Weapon_Bow_029	一心之弓",
        "弓	Weapon_Bow_030	钢铁蜥蜴弓",
        "弓	Weapon_Bow_032	兽神弓",
        "弓	Weapon_Bow_033	近卫之弓",
        "弓	Weapon_Bow_035	骑士之弓",
        "弓	Weapon_Bow_036	王族之弓",
        "弓	Weapon_Bow_038	木之弓",
        "弓	Weapon_Bow_040	二连弓",
        "弓	Weapon_Bow_071	光之弓箭",
        "弓	Weapon_Bow_072	黄昏之光弓",
        "盾	Weapon_Shield_001	木盾",
        "盾	Weapon_Shield_002	士兵盾",
        "盾	Weapon_Shield_003	骑士盾",
        "盾	Weapon_Shield_004	波克盾",
        "盾	Weapon_Shield_005	尖刺波克盾",
        "盾	Weapon_Shield_006	龙骨波克盾",
        "盾	Weapon_Shield_007	蜥蜴盾",
        "盾	Weapon_Shield_008	强力蜥蜴盾",
        "盾	Weapon_Shield_009	钢铁蜥蜴盾",
        "盾	Weapon_Shield_013	守护者之盾",
        "盾	Weapon_Shield_014	守护者之盾+",
        "盾	Weapon_Shield_015	守护者之盾++",
        "盾	Weapon_Shield_016	莱尼尔盾",
        "盾	Weapon_Shield_017	兽王盾",
        "盾	Weapon_Shield_018	兽神盾",
        "盾	Weapon_Shield_021	生锈的盾",
        "盾	Weapon_Shield_022	王族盾",
        "盾	Weapon_Shield_023	森民盾",
        "盾	Weapon_Shield_025	卓拉盾",
        "盾	Weapon_Shield_026	格鲁德盾",
        "盾	Weapon_Shield_030	海利亚盾",
        "盾	Weapon_Shield_031	兔纹盾",
        "盾	Weapon_Shield_032	鱼纹盾",
        "盾	Weapon_Shield_033	近卫盾",
        "盾	Weapon_Shield_034	兽纹盾",
        "盾	Weapon_Shield_035	旅人盾",
        "盾	Weapon_Shield_036	太阳盾",
        "盾	Weapon_Shield_037	七宝盾",
        "盾	Weapon_Shield_038	古代兵装·盾",
        "盾	Weapon_Shield_040	锅盖",
        "盾	Weapon_Shield_041	护心盾",
        "盾	Weapon_Shield_042	风筝盾",
        "盾	Weapon_Shield_057	勇者盾",
        "防具	Armor_001_Head	海利亚兜帽",
        "防具	Armor_001_Lower	海利亚裤子",
        "防具	Armor_001_Upper	海利亚服",
        "防具	Armor_002_Head	海利亚兜帽",
        "防具	Armor_002_Lower	海利亚裤子",
        "防具	Armor_002_Upper	海利亚服",
        "防具	Armor_003_Head	海利亚兜帽",
        "防具	Armor_003_Lower	海利亚裤子",
        "防具	Armor_003_Upper	海利亚服",
        "防具	Armor_004_Head	海利亚兜帽",
        "防具	Armor_004_Lower	海利亚裤子",
        "防具	Armor_004_Upper	海利亚服",
        "防具	Armor_005_Head	旷野之勇者帽子",
        "防具	Armor_005_Lower	旷野之勇者裤子",
        "防具	Armor_005_Upper	旷野之勇者服",
        "防具	Armor_006_Head	卓拉头盔",
        "防具	Armor_006_Lower	卓拉护胫",
        "防具	Armor_006_Upper	卓拉铠甲",
        "防具	Armor_007_Head	卓拉头盔",
        "防具	Armor_007_Lower	卓拉护胫",
        "防具	Armor_007_Upper	卓拉铠甲",
        "防具	Armor_008_Head	热沙护额",
        "防具	Armor_008_Lower	热沙裤子",
        "防具	Armor_008_Upper	热沙护肩",
        "防具	Armor_009_Head	防雪羽饰",
        "防具	Armor_009_Lower	利特的羽绒裤",
        "防具	Armor_009_Upper	利特的羽绒服",
        "防具	Armor_011_Head	耐火石盔",
        "防具	Armor_011_Lower	耐火石鞋",
        "防具	Armor_011_Upper	耐火石铠",
        "防具	Armor_012_Head	潜行面罩",
        "防具	Armor_012_Lower	潜行紧身裤",
        "防具	Armor_012_Upper	潜行紧身服",
        "防具	Armor_014_Head	攀登头巾",
        "防具	Armor_014_Lower	攀登鞋",
        "防具	Armor_014_Upper	攀登护手",
        "防具	Armor_015_Head	海利亚兜帽",
        "防具	Armor_015_Lower	海利亚裤子",
        "防具	Armor_015_Upper	海利亚服",
        "防具	Armor_017_Head	夜光面罩",
        "防具	Armor_017_Lower	夜光紧身裤",
        "防具	Armor_017_Upper	夜光紧身服",
        "防具	Armor_020_Head	海利亚士兵头盔",
        "防具	Armor_020_Lower	海利亚士兵护胫",
        "防具	Armor_020_Upper	海利亚士兵铠甲",
        "防具	Armor_021_Head	古代兵装·头盔",
        "防具	Armor_021_Lower	古代兵装·下身铠",
        "防具	Armor_021_Upper	古代兵装·上身铠",
        "防具	Armor_022_Head	波克布林面罩",
        "防具	Armor_024_Head	钻石头饰",
        "防具	Armor_025_Head	红宝石头饰",
        "防具	Armor_026_Head	蓝宝石头饰",
        "防具	Armor_027_Head	黄玉耳坠",
        "防具	Armor_028_Head	蛋白石耳坠",
        "防具	Armor_029_Head	琥珀耳坠",
        "防具	Armor_035_Head	旷野之勇者帽子",
        "防具	Armor_035_Lower	旷野之勇者裤子",
        "防具	Armor_035_Upper	旷野之勇者服",
        "防具	Armor_036_Head	防雪羽饰",
        "防具	Armor_036_Lower	利特的羽绒裤",
        "防具	Armor_036_Upper	利特的羽绒服",
        "防具	Armor_037_Head	耐火石盔",
        "防具	Armor_037_Lower	耐火石鞋",
        "防具	Armor_037_Upper	耐火石铠",
        "防具	Armor_039_Head	旷野之勇者帽子",
        "防具	Armor_039_Lower	旷野之勇者裤子",
        "防具	Armor_039_Upper	旷野之勇者服",
        "防具	Armor_040_Head	热沙护额",
        "防具	Armor_040_Lower	热沙裤子",
        "防具	Armor_040_Upper	热沙护肩",
        "防具	Armor_042_Head	潜行面罩",
        "防具	Armor_042_Upper	潜行紧身服",
        "防具	Armor_043_Lower	老旧的裤子",
        "防具	Armor_043_Upper	老旧的衬衫",
        "防具	Armor_044_Upper	防寒服",
        "防具	Armor_045_Head	莫力布林面罩",
        "防具	Armor_046_Head	橡胶头盔",
        "防具	Armor_046_Lower	橡胶紧身裤",
        "防具	Armor_046_Upper	橡胶紧身服",
        "防具	Armor_048_Head	蛮族头盔",
        "防具	Armor_048_Lower	蛮族短裤",
        "防具	Armor_048_Upper	蛮族服",
        "防具	Armor_049_Lower	沙地靴",
        "防具	Armor_053_Head	淑女面罩",
        "防具	Armor_053_Lower	淑女裤子",
        "防具	Armor_053_Upper	淑女服",
        "防具	Armor_055_Head	蜥蜴战士面罩",
        "防具	Armor_056_Head	莱尼尔面罩",
        "防具	Armor_060_Head	旷野之勇者帽子",
        "防具	Armor_060_Lower	旷野之勇者裤子",
        "防具	Armor_060_Upper	旷野之勇者服",
        "防具	Armor_061_Head	旷野之勇者帽子",
        "防具	Armor_061_Lower	旷野之勇者裤子",
        "防具	Armor_061_Upper	旷野之勇者服",
        "防具	Armor_062_Head	卓拉头盔",
        "防具	Armor_062_Lower	卓拉护胫",
        "防具	Armor_062_Upper	卓拉铠甲",
        "防具	Armor_063_Head	卓拉头盔",
        "防具	Armor_063_Lower	卓拉护胫",
        "防具	Armor_063_Upper	卓拉铠甲",
        "防具	Armor_064_Head	卓拉头盔",
        "防具	Armor_064_Lower	卓拉护胫",
        "防具	Armor_064_Upper	卓拉铠甲",
        "防具	Armor_065_Head	热沙护额",
        "防具	Armor_065_Lower	热沙裤子",
        "防具	Armor_065_Upper	热沙护肩",
        "防具	Armor_066_Head	热沙护额",
        "防具	Armor_066_Lower	热沙裤子",
        "防具	Armor_066_Upper	热沙护肩",
        "防具	Armor_067_Head	热沙护额",
        "防具	Armor_067_Lower	热沙裤子",
        "防具	Armor_067_Upper	热沙护肩",
        "防具	Armor_071_Head	防雪羽饰",
        "防具	Armor_071_Lower	利特的羽绒裤",
        "防具	Armor_071_Upper	利特的羽绒服",
        "防具	Armor_072_Head	防雪羽饰",
        "防具	Armor_072_Lower	利特的羽绒裤",
        "防具	Armor_072_Upper	利特的羽绒服",
        "防具	Armor_073_Head	防雪羽饰",
        "防具	Armor_073_Lower	利特的羽绒裤",
        "防具	Armor_073_Upper	利特的羽绒服",
        "防具	Armor_074_Head	耐火石盔",
        "防具	Armor_074_Lower	耐火石鞋",
        "防具	Armor_074_Upper	耐火石铠",
        "防具	Armor_075_Head	耐火石盔",
        "防具	Armor_075_Lower	耐火石鞋",
        "防具	Armor_075_Upper	耐火石铠",
        "防具	Armor_076_Head	耐火石盔",
        "防具	Armor_076_Lower	耐火石鞋",
        "防具	Armor_076_Upper	耐火石铠",
        "防具	Armor_077_Head	潜行面罩",
        "防具	Armor_077_Lower	潜行紧身裤",
        "防具	Armor_077_Upper	潜行紧身服",
        "防具	Armor_078_Head	潜行面罩",
        "防具	Armor_078_Lower	潜行紧身裤",
        "防具	Armor_078_Upper	潜行紧身服",
        "防具	Armor_079_Head	潜行面罩",
        "防具	Armor_079_Lower	潜行紧身裤",
        "防具	Armor_079_Upper	潜行紧身服",
        "防具	Armor_083_Head	攀登头巾",
        "防具	Armor_083_Lower	攀登鞋",
        "防具	Armor_083_Upper	攀登护手",
        "防具	Armor_084_Head	攀登头巾",
        "防具	Armor_084_Lower	攀登鞋",
        "防具	Armor_084_Upper	攀登护手",
        "防具	Armor_085_Head	攀登头巾",
        "防具	Armor_085_Lower	攀登鞋",
        "防具	Armor_085_Upper	攀登护手",
        "防具	Armor_086_Head	攀登头巾",
        "防具	Armor_086_Lower	攀登鞋",
        "防具	Armor_086_Upper	攀登护手",
        "防具	Armor_087_Head	夜光面罩",
        "防具	Armor_087_Lower	夜光紧身裤",
        "防具	Armor_087_Upper	夜光紧身服",
        "防具	Armor_088_Head	夜光面罩",
        "防具	Armor_088_Lower	夜光紧身裤",
        "防具	Armor_088_Upper	夜光紧身服",
        "防具	Armor_089_Head	夜光面罩",
        "防具	Armor_089_Lower	夜光紧身裤",
        "防具	Armor_089_Upper	夜光紧身服",
        "防具	Armor_090_Head	夜光面罩",
        "防具	Armor_090_Lower	夜光紧身裤",
        "防具	Armor_090_Upper	夜光紧身服",
        "防具	Armor_095_Head	海利亚士兵头盔",
        "防具	Armor_095_Lower	海利亚士兵护胫",
        "防具	Armor_095_Upper	海利亚士兵铠甲",
        "防具	Armor_096_Head	海利亚士兵头盔",
        "防具	Armor_096_Lower	海利亚士兵护胫",
        "防具	Armor_096_Upper	海利亚士兵铠甲",
        "防具	Armor_097_Head	海利亚士兵头盔",
        "防具	Armor_097_Lower	海利亚士兵护胫",
        "防具	Armor_097_Upper	海利亚士兵铠甲",
        "防具	Armor_098_Head	海利亚士兵头盔",
        "防具	Armor_098_Lower	海利亚士兵护胫",
        "防具	Armor_098_Upper	海利亚士兵铠甲",
        "防具	Armor_099_Head	古代兵装·头盔",
        "防具	Armor_099_Lower	古代兵装·下身铠",
        "防具	Armor_099_Upper	古代兵装·上身铠",
        "防具	Armor_100_Head	古代兵装·头盔",
        "防具	Armor_100_Lower	古代兵装·下身铠",
        "防具	Armor_100_Upper	古代兵装·上身铠",
        "防具	Armor_101_Head	古代兵装·头盔",
        "防具	Armor_101_Lower	古代兵装·下身铠",
        "防具	Armor_101_Upper	古代兵装·上身铠",
        "防具	Armor_102_Head	古代兵装·头盔",
        "防具	Armor_102_Lower	古代兵装·下身铠",
        "防具	Armor_102_Upper	古代兵装·上身铠",
        "防具	Armor_103_Head	橡胶头盔",
        "防具	Armor_103_Lower	橡胶紧身裤",
        "防具	Armor_103_Upper	橡胶紧身服",
        "防具	Armor_104_Head	橡胶头盔",
        "防具	Armor_104_Lower	橡胶紧身裤",
        "防具	Armor_104_Upper	橡胶紧身服",
        "防具	Armor_105_Head	橡胶头盔",
        "防具	Armor_105_Lower	橡胶紧身裤",
        "防具	Armor_105_Upper	橡胶紧身服",
        "防具	Armor_106_Head	橡胶头盔",
        "防具	Armor_106_Lower	橡胶紧身裤",
        "防具	Armor_106_Upper	橡胶紧身服",
        "防具	Armor_111_Head	蛮族头盔",
        "防具	Armor_111_Lower	蛮族短裤",
        "防具	Armor_111_Upper	蛮族服",
        "防具	Armor_112_Head	蛮族头盔",
        "防具	Armor_112_Lower	蛮族短裤",
        "防具	Armor_112_Upper	蛮族服",
        "防具	Armor_113_Head	蛮族头盔",
        "防具	Armor_113_Lower	蛮族短裤",
        "防具	Armor_113_Upper	蛮族服",
        "防具	Armor_114_Head	蛮族头盔",
        "防具	Armor_114_Lower	蛮族短裤",
        "防具	Armor_114_Upper	蛮族服",
        "防具	Armor_115_Head	雷鸣头盔",
        "防具	Armor_116_Upper	英杰服",
        "防具	Armor_117_Head	钻石头饰",
        "防具	Armor_118_Head	钻石头饰",
        "防具	Armor_120_Head	钻石头饰",
        "防具	Armor_121_Head	红宝石头饰",
        "防具	Armor_122_Head	红宝石头饰",
        "防具	Armor_123_Head	红宝石头饰",
        "防具	Armor_124_Head	红宝石头饰",
        "防具	Armor_125_Head	蓝宝石头饰",
        "防具	Armor_126_Head	蓝宝石头饰",
        "防具	Armor_127_Head	蓝宝石头饰",
        "防具	Armor_128_Head	蓝宝石头饰",
        "防具	Armor_129_Head	黄玉耳坠",
        "防具	Armor_130_Head	黄玉耳坠",
        "防具	Armor_131_Head	黄玉耳坠",
        "防具	Armor_132_Head	黄玉耳坠",
        "防具	Armor_133_Head	蛋白石耳坠",
        "防具	Armor_134_Head	蛋白石耳坠",
        "防具	Armor_135_Head	蛋白石耳坠",
        "防具	Armor_136_Head	蛋白石耳坠",
        "防具	Armor_137_Head	琥珀耳坠",
        "防具	Armor_138_Head	琥珀耳坠",
        "防具	Armor_139_Head	琥珀耳坠",
        "防具	Armor_140_Head	琥珀耳坠",
        "防具	Armor_140_Lower	雪地靴",
        "防具	Armor_141_Lower	雪地靴",
        "防具	Armor_148_Upper	英杰服",
        "防具	Armor_149_Upper	英杰服",
        "防具	Armor_150_Upper	英杰服",
        "防具	Armor_151_Upper	英杰服",
        "防具	Armor_152_Lower	沙地靴",
        "防具	Armor_153_Lower	沙地靴",
        "防具	Armor_154_Lower	沙地靴",
        "防具	Armor_155_Lower	沙地靴",
        "防具	Armor_156_Lower	雪地靴",
        "防具	Armor_157_Lower	雪地靴",
        "防具	Armor_158_Lower	雪地靴",
        "防具	Armor_159_Lower	雪地靴",
        "防具	Armor_160_Head	黑暗头套",
        "防具	Armor_160_Lower	黑暗裤子",
        "防具	Armor_160_Upper	黑暗外衣",
        "防具	Armor_168_Head	神兽兵装·娜波力斯",
        "防具	Armor_169_Head	神兽兵装·娜波力斯",
        "防具	Armor_170_Upper	它的衬衫",
        "防具	Armor_171_Head	幻影头盔",
        "防具	Armor_171_Lower	幻影护胫",
        "防具	Armor_171_Upper	幻影铠甲",
        "防具	Armor_172_Head	魔吉拉的面具",
        "防具	Armor_173_Head	米多娜的王冠",
        "防具	Armor_174_Head	汀空的头巾",
        "防具	Armor_174_Lower	汀空的裤子",
        "防具	Armor_174_Upper	汀空的衣服",
        "防具	Armor_175_Upper	蓝色大虾衬衫",
        "防具	Armor_176_Head	克洛格的面具",
        "防具	Armor_177_Head	罗维奥的头巾",
        "防具	Armor_178_Head	藏特头盔",
        "防具	Armor_179_Head	近卫兵的帽子",
        "防具	Armor_179_Lower	近卫兵的靴子",
        "防具	Armor_179_Upper	近卫兵的衣服",
        "防具	Armor_180_Head	幻影盖侬头盔",
        "防具	Armor_180_Lower	幻影盖侬胫甲",
        "防具	Armor_180_Upper	幻影盖侬铠甲",
        "防具	Armor_181_Head	神兽兵装·露塔",
        "防具	Armor_182_Head	神兽兵装·梅德",
        "防具	Armor_183_Head	神兽兵装·鲁达尼亚",
        "防具	Armor_184_Head	神兽兵装·娜波力斯",
        "防具	Armor_185_Head	打捞员头盔",
        "防具	Armor_185_Lower	打捞员裤子",
        "防具	Armor_185_Upper	打捞员外衣",
        "防具	Armor_186_Head	神兽兵装·露塔",
        "防具	Armor_187_Head	神兽兵装·露塔",
        "防具	Armor_188_Head	神兽兵装·露塔",
        "防具	Armor_189_Head	神兽兵装·露塔",
        "防具	Armor_190_Head	神兽兵装·梅德",
        "防具	Armor_191_Head	神兽兵装·梅德",
        "防具	Armor_192_Head	神兽兵装·梅德",
        "防具	Armor_193_Head	神兽兵装·梅德",
        "防具	Armor_194_Head	神兽兵装·鲁达尼亚",
        "防具	Armor_195_Head	神兽兵装·鲁达尼亚",
        "防具	Armor_196_Head	神兽兵装·鲁达尼亚",
        "防具	Armor_197_Head	神兽兵装·鲁达尼亚",
        "防具	Armor_198_Head	神兽兵装·娜波力斯",
        "防具	Armor_199_Head	神兽兵装·娜波力斯",
        "防具	Armor_200_Head	时光之勇者帽子",
        "防具	Armor_200_Lower	时光之勇者裤子",
        "防具	Armor_200_Upper	时光之勇者服",
        "防具	Armor_201_Head	时光之勇者帽子",
        "防具	Armor_201_Lower	时光之勇者裤子",
        "防具	Armor_201_Upper	时光之勇者服",
        "防具	Armor_202_Head	时光之勇者帽子",
        "防具	Armor_202_Lower	时光之勇者裤子",
        "防具	Armor_202_Upper	时光之勇者服",
        "防具	Armor_203_Head	时光之勇者帽子",
        "防具	Armor_203_Lower	时光之勇者裤子",
        "防具	Armor_203_Upper	时光之勇者服",
        "防具	Armor_204_Head	时光之勇者帽子",
        "防具	Armor_204_Lower	时光之勇者裤子",
        "防具	Armor_204_Upper	时光之勇者服",
        "防具	Armor_205_Head	风之勇者帽子",
        "防具	Armor_205_Lower	风之勇者裤子",
        "防具	Armor_205_Upper	风之勇者服",
        "防具	Armor_206_Head	风之勇者帽子",
        "防具	Armor_206_Lower	风之勇者裤子",
        "防具	Armor_206_Upper	风之勇者服",
        "防具	Armor_207_Head	风之勇者帽子",
        "防具	Armor_207_Lower	风之勇者裤子",
        "防具	Armor_207_Upper	风之勇者服",
        "防具	Armor_208_Head	风之勇者帽子",
        "防具	Armor_208_Lower	风之勇者裤子",
        "防具	Armor_208_Upper	风之勇者服",
        "防具	Armor_209_Head	风之勇者帽子",
        "防具	Armor_209_Lower	风之勇者裤子",
        "防具	Armor_209_Upper	风之勇者服",
        "防具	Armor_210_Head	黄昏之勇者帽子",
        "防具	Armor_210_Lower	黄昏之勇者裤子",
        "防具	Armor_210_Upper	黄昏之勇者服",
        "防具	Armor_211_Head	黄昏之勇者帽子",
        "防具	Armor_211_Lower	黄昏之勇者裤子",
        "防具	Armor_211_Upper	黄昏之勇者服",
        "防具	Armor_212_Head	黄昏之勇者帽子",
        "防具	Armor_212_Lower	黄昏之勇者裤子",
        "防具	Armor_212_Upper	黄昏之勇者服",
        "防具	Armor_213_Head	黄昏之勇者帽子",
        "防具	Armor_213_Lower	黄昏之勇者裤子",
        "防具	Armor_213_Upper	黄昏之勇者服",
        "防具	Armor_214_Head	黄昏之勇者帽子",
        "防具	Armor_214_Lower	黄昏之勇者裤子",
        "防具	Armor_214_Upper	黄昏之勇者服",
        "防具	Armor_215_Head	天空之勇者帽子",
        "防具	Armor_215_Lower	天空之勇者裤子",
        "防具	Armor_215_Upper	天空之勇者服",
        "防具	Armor_216_Head	天空之勇者帽子",
        "防具	Armor_216_Lower	天空之勇者裤子",
        "防具	Armor_216_Upper	天空之勇者服",
        "防具	Armor_217_Head	天空之勇者帽子",
        "防具	Armor_217_Lower	天空之勇者裤子",
        "防具	Armor_217_Upper	天空之勇者服",
        "防具	Armor_218_Head	天空之勇者帽子",
        "防具	Armor_218_Lower	天空之勇者裤子",
        "防具	Armor_218_Upper	天空之勇者服",
        "防具	Armor_219_Head	天空之勇者帽子",
        "防具	Armor_219_Lower	天空之勇者裤子",
        "防具	Armor_219_Upper	天空之勇者服",
        "防具	Armor_220_Head	希克面罩",
        "防具	Armor_221_Head	希克面罩",
        "防具	Armor_222_Head	希克面罩",
        "防具	Armor_223_Head	希克面罩",
        "防具	Armor_224_Head	希克面罩",
        "防具	Armor_225_Head	鬼神帽子",
        "防具	Armor_225_Lower	鬼神靴",
        "防具	Armor_225_Upper	鬼神服",
        "防具	Armor_226_Head	鬼神帽子",
        "防具	Armor_226_Lower	鬼神靴",
        "防具	Armor_226_Upper	鬼神服",
        "防具	Armor_227_Head	鬼神帽子",
        "防具	Armor_227_Lower	鬼神靴",
        "防具	Armor_227_Upper	鬼神服",
        "防具	Armor_228_Head	鬼神帽子",
        "防具	Armor_228_Lower	鬼神靴",
        "防具	Armor_228_Upper	鬼神服",
        "防具	Armor_229_Head	鬼神帽子",
        "防具	Armor_229_Lower	鬼神靴",
        "防具	Armor_229_Upper	鬼神服",
        "防具	Armor_230_Head	初始之勇者帽子",
        "防具	Armor_230_Lower	初始之勇者裤子",
        "防具	Armor_230_Upper	初始之勇者服",
        "防具	Armor_231_Head	初始之勇者帽子",
        "防具	Armor_231_Lower	初始之勇者裤子",
        "防具	Armor_231_Upper	初始之勇者服",
        "防具	Armor_232_Head	初始之勇者帽子",
        "防具	Armor_232_Lower	初始之勇者裤子",
        "防具	Armor_232_Upper	初始之勇者服",
        "防具	Armor_233_Head	初始之勇者帽子",
        "防具	Armor_233_Lower	初始之勇者裤子",
        "防具	Armor_233_Upper	初始之勇者服",
        "防具	Armor_234_Head	初始之勇者帽子",
        "防具	Armor_234_Lower	初始之勇者裤子",
        "防具	Armor_234_Upper	初始之勇者服",
        "材料·食物	Item_Boiled_01	煮蛋",
        "材料·食物	Item_ChilledFish_01	冰冻鲈鱼",
        "材料·食物	Item_ChilledFish_02	冰冻生命三文鱼",
        "材料·食物	Item_ChilledFish_03	冰冻鳟鱼",
        "材料·食物	Item_ChilledFish_04	冰冻鲤鱼",
        "材料·食物	Item_ChilledFish_05	冰冻鲷鱼",
        "材料·食物	Item_ChilledFish_06	冰冻生命鲈鱼",
        "材料·食物	Item_ChilledFish_07	冰冻螃蟹",
        "材料·食物	Item_ChilledFish_08	冰冻田螺",
        "材料·食物	Item_ChilledFish_09	冰冻生命海螺",
        "材料·食物	Item_Chilled_01	冰冻兽肉",
        "材料·食物	Item_Chilled_02	高级冰冻兽肉",
        "材料·食物	Item_Chilled_03	顶级冰冻兽肉",
        "材料·食物	Item_Chilled_04	冰冻禽肉",
        "材料·食物	Item_Chilled_05	高级冰冻禽肉",
        "材料·食物	Item_Chilled_06	顶级冰冻禽肉",
        "材料·食物	Item_Cook_A_01	",
        "材料·食物	Item_Cook_A_02	",
        "材料·食物	Item_Cook_A_03	",
        "材料·食物	Item_Cook_A_04	",
        "材料·食物	Item_Cook_A_05	",
        "材料·食物	Item_Cook_A_07	",
        "材料·食物	Item_Cook_A_08	",
        "材料·食物	Item_Cook_A_09	",
        "材料·食物	Item_Cook_A_10	",
        "材料·食物	Item_Cook_A_11	",
        "材料·食物	Item_Cook_A_12	",
        "材料·食物	Item_Cook_A_13	",
        "材料·食物	Item_Cook_A_14	",
        "材料·食物	Item_Cook_B_01	",
        "材料·食物	Item_Cook_B_02	",
        "材料·食物	Item_Cook_B_05	",
        "材料·食物	Item_Cook_B_06	",
        "材料·食物	Item_Cook_B_11	",
        "材料·食物	Item_Cook_B_12	",
        "材料·食物	Item_Cook_B_13	",
        "材料·食物	Item_Cook_B_15	",
        "材料·食物	Item_Cook_B_16	",
        "材料·食物	Item_Cook_B_17	",
        "材料·食物	Item_Cook_B_18	",
        "材料·食物	Item_Cook_B_19	",
        "材料·食物	Item_Cook_B_20	",
        "材料·食物	Item_Cook_B_21	",
        "材料·食物	Item_Cook_B_22	",
        "材料·食物	Item_Cook_B_23	",
        "材料·食物	Item_Cook_C_16	",
        "材料·食物	Item_Cook_C_17	",
        "材料·食物	Item_Cook_C_17_00	",
        "材料·食物	Item_Cook_D_01	",
        "材料·食物	Item_Cook_D_02	",
        "材料·食物	Item_Cook_D_03	",
        "材料·食物	Item_Cook_D_04	",
        "材料·食物	Item_Cook_D_05	",
        "材料·食物	Item_Cook_D_06	",
        "材料·食物	Item_Cook_D_07	",
        "材料·食物	Item_Cook_D_08	",
        "材料·食物	Item_Cook_D_09	",
        "材料·食物	Item_Cook_D_10	",
        "材料·食物	Item_Cook_E_01	",
        "材料·食物	Item_Cook_E_02	",
        "材料·食物	Item_Cook_E_03	",
        "材料·食物	Item_Cook_E_04	",
        "材料·食物	Item_Cook_F_01	",
        "材料·食物	Item_Cook_F_02	",
        "材料·食物	Item_Cook_F_03	",
        "材料·食物	Item_Cook_F_04	",
        "材料·食物	Item_Cook_G_02	",
        "材料·食物	Item_Cook_G_03	",
        "材料·食物	Item_Cook_G_04	",
        "材料·食物	Item_Cook_G_05	",
        "材料·食物	Item_Cook_G_06	",
        "材料·食物	Item_Cook_G_09	",
        "材料·食物	Item_Cook_G_10	",
        "材料·食物	Item_Cook_G_11	",
        "材料·食物	Item_Cook_G_12	",
        "材料·食物	Item_Cook_G_13	",
        "材料·食物	Item_Cook_G_14	",
        "材料·食物	Item_Cook_G_15	",
        "材料·食物	Item_Cook_G_16	",
        "材料·食物	Item_Cook_G_17	",
        "材料·食物	Item_Cook_H_01	",
        "材料·食物	Item_Cook_H_02	",
        "材料·食物	Item_Cook_H_03	",
        "材料·食物	Item_Cook_I_01	",
        "材料·食物	Item_Cook_I_02	",
        "材料·食物	Item_Cook_I_03	",
        "材料·食物	Item_Cook_I_04	",
        "材料·食物	Item_Cook_I_05	",
        "材料·食物	Item_Cook_I_06	",
        "材料·食物	Item_Cook_I_07	",
        "材料·食物	Item_Cook_I_08	",
        "材料·食物	Item_Cook_I_09	",
        "材料·食物	Item_Cook_I_10	",
        "材料·食物	Item_Cook_I_11	",
        "材料·食物	Item_Cook_I_12	",
        "材料·食物	Item_Cook_I_13	",
        "材料·食物	Item_Cook_I_14	",
        "材料·食物	Item_Cook_I_15	",
        "材料·食物	Item_Cook_I_16	",
        "材料·食物	Item_Cook_I_17	",
        "材料·食物	Item_Cook_J_01	",
        "材料·食物	Item_Cook_J_02	",
        "材料·食物	Item_Cook_J_03	",
        "材料·食物	Item_Cook_J_04	",
        "材料·食物	Item_Cook_J_05	",
        "材料·食物	Item_Cook_J_06	",
        "材料·食物	Item_Cook_J_07	",
        "材料·食物	Item_Cook_J_08	",
        "材料·食物	Item_Cook_J_09	",
        "材料·食物	Item_Cook_K_01	",
        "材料·食物	Item_Cook_K_02	",
        "材料·食物	Item_Cook_K_03	",
        "材料·食物	Item_Cook_K_04	",
        "材料·食物	Item_Cook_K_05	",
        "材料·食物	Item_Cook_K_06	",
        "材料·食物	Item_Cook_K_07	",
        "材料·食物	Item_Cook_K_08	",
        "材料·食物	Item_Cook_K_09	",
        "材料·食物	Item_Cook_L_01	",
        "材料·食物	Item_Cook_L_02	",
        "材料·食物	Item_Cook_L_03	",
        "材料·食物	Item_Cook_L_04	",
        "材料·食物	Item_Cook_L_05	",
        "材料·食物	Item_Cook_M_01	",
        "材料·食物	Item_Cook_N_01	",
        "材料·食物	Item_Cook_N_02	",
        "材料·食物	Item_Cook_N_03	",
        "材料·食物	Item_Cook_N_04	",
        "材料·食物	Item_Cook_O_01	",
        "材料·食物	Item_Cook_O_02	",
        "材料·食物	Item_Cook_P_01	",
        "材料·食物	Item_Cook_P_02	",
        "材料·食物	Item_Cook_P_03	",
        "材料·食物	Item_Cook_P_04	",
        "材料·食物	Item_Cook_P_05	",
        "材料·食物	Item_Enemy_00	波克布林的犄角",
        "材料·食物	Item_Enemy_01	波克布林的牙齿",
        "材料·食物	Item_Enemy_02	波克布林的肝脏",
        "材料·食物	Item_Enemy_03	蜥蜴战士的犄角",
        "材料·食物	Item_Enemy_04	蜥蜴战士的爪子",
        "材料·食物	Item_Enemy_05	蜥蜴战士的尾巴",
        "材料·食物	Item_Enemy_06	莫力布林的犄角",
        "材料·食物	Item_Enemy_07	莫力布林的牙齿",
        "材料·食物	Item_Enemy_08	莫力布林的肝脏",
        "材料·食物	Item_Enemy_12	莱尼尔的犄角",
        "材料·食物	Item_Enemy_13	莱尼尔的蹄子",
        "材料·食物	Item_Enemy_14	莱尼尔的肝脏",
        "材料·食物	Item_Enemy_15	红色丘丘胶",
        "材料·食物	Item_Enemy_16	黄色丘丘胶",
        "材料·食物	Item_Enemy_17	白色丘丘胶",
        "材料·食物	Item_Enemy_18	蝙蝠的翅膀",
        "材料·食物	Item_Enemy_19	蝙蝠的眼珠",
        "材料·食物	Item_Enemy_20	八爪怪的脚",
        "材料·食物	Item_Enemy_21	八爪怪的眼珠",
        "材料·食物	Item_Enemy_24	莫尔德拉吉克的背鳍",
        "材料·食物	Item_Enemy_25	莫尔德拉吉克的肝脏",
        "材料·食物	Item_Enemy_26	古代齿轮",
        "材料·食物	Item_Enemy_27	古代螺丝",
        "材料·食物	Item_Enemy_28	古代弹簧",
        "材料·食物	Item_Enemy_29	古代传动轴",
        "材料·食物	Item_Enemy_30	古代核心",
        "材料·食物	Item_Enemy_31	巨大的古代核心",
        "材料·食物	Item_Enemy_32	西诺克斯的爪子",
        "材料·食物	Item_Enemy_33	西诺克斯的牙齿",
        "材料·食物	Item_Enemy_34	西诺克斯的肝脏",
        "材料·食物	Item_Enemy_38	奥尔龙的鳞片",
        "材料·食物	Item_Enemy_39	奥尔龙的爪子",
        "材料·食物	Item_Enemy_40	丘丘胶",
        "材料·食物	Item_Enemy_41	蜥蜴战士的红色尾巴",
        "材料·食物	Item_Enemy_42	蜥蜴战士的蓝色尾巴",
        "材料·食物	Item_Enemy_43	蜥蜴战士的黄色尾巴",
        "材料·食物	Item_Enemy_44	火蝙蝠的翅膀",
        "材料·食物	Item_Enemy_45	电蝙蝠的翅膀",
        "材料·食物	Item_Enemy_46	冰蝙蝠的翅膀",
        "材料·食物	Item_Enemy_47	奥尔龙的牙齿碎片",
        "材料·食物	Item_Enemy_48	奥尔龙的犄角碎片",
        "材料·食物	Item_Enemy_49	聂尔龙的鳞片",
        "材料·食物	Item_Enemy_50	聂尔龙的爪子",
        "材料·食物	Item_Enemy_51	聂尔龙的牙齿碎片",
        "材料·食物	Item_Enemy_52	聂尔龙的犄角碎片",
        "材料·食物	Item_Enemy_53	费罗龙的鳞片",
        "材料·食物	Item_Enemy_54	费罗龙的爪子",
        "材料·食物	Item_Enemy_55	费罗龙的牙齿碎片",
        "材料·食物	Item_Enemy_56	费罗龙的犄角碎片",
        "材料·食物	Item_Enemy_57	八爪怪气球",
        "材料·食物	Item_FishGet_A	海拉鲁鲈鱼",
        "材料·食物	Item_FishGet_B	生命鲈鱼",
        "材料·食物	Item_FishGet_C	冰冷鳟鱼",
        "材料·食物	Item_FishGet_D	酥麻鳟鱼",
        "材料·食物	Item_FishGet_E	大剑鲤鱼",
        "材料·食物	Item_FishGet_F	大剑鲷鱼",
        "材料·食物	Item_FishGet_G	铠甲鲷鱼",
        "材料·食物	Item_FishGet_H	铠甲鲤鱼",
        "材料·食物	Item_FishGet_I	生命三文鱼",
        "材料·食物	Item_FishGet_J	暖暖鳟鱼",
        "材料·食物	Item_FishGet_K	生命海螺",
        "材料·食物	Item_FishGet_L	精力鲈鱼",
        "材料·食物	Item_FishGet_L_00	精力鲈鱼 x ",
        "GiveItemNumbe",
        "材料·食物	Item_FishGet_M	潜行田螺",
        "材料·食物	Item_FishGet_X	潜行鳟鱼",
        "材料·食物	Item_FishGet_Z	三色鲤鱼",
        "材料·食物	Item_Fruit_A	苹果",
        "材料·食物	Item_Fruit_B	草莓",
        "材料·食物	Item_Fruit_C	酥麻水果",
        "材料·食物	Item_Fruit_D	生命榴莲",
        "材料·食物	Item_Fruit_E	速速莲蓬",
        "材料·食物	Item_Fruit_E_00	速速莲蓬 x ",
        "GiveItemNumbe",
        "材料·食物	Item_Fruit_F	冰冷蜜瓜",
        "材料·食物	Item_Fruit_G	椰子",
        "材料·食物	Item_Fruit_H	大剑香蕉",
        "材料·食物	Item_Fruit_I	暖暖草果",
        "材料·食物	Item_Fruit_J	铠甲南瓜",
        "材料·食物	Item_Fruit_K	橡子",
        "材料·食物	Item_Fruit_L	小鸟的树果",
        "材料·食物	Item_InsectGet_K	大剑螃蟹",
        "材料·食物	Item_InsectGet_O	铠甲螃蟹",
        "材料·食物	Item_InsectGet_Z	精力螃蟹",
        "材料·食物	Item_Material_01	蔗糖",
        "材料·食物	Item_Material_02	鼓隆的调味粉",
        "材料·食物	Item_Material_03	海拉鲁米",
        "材料·食物	Item_Material_04	禽蛋",
        "材料·食物	Item_Material_05	鲜奶",
        "材料·食物	Item_Material_05_00	鲜奶 x ",
        "GiveItemNumber",
        "材料·食物	Item_Material_06	山羊黄油",
        "材料·食物	Item_Material_07	塔邦挞小麦",
        "材料·食物	Item_Material_08	怪物精华",
        "材料·食物	Item_Meat_01	兽肉",
        "材料·食物	Item_Meat_02	高级兽肉",
        "材料·食物	Item_Meat_06	禽肉",
        "材料·食物	Item_Meat_07	高级禽肉",
        "材料·食物	Item_Meat_11	顶级兽肉",
        "材料·食物	Item_Meat_12	顶级禽肉",
        "材料·食物	Item_MushroomGet_D	速速蘑菇",
        "材料·食物	Item_Mushroom_A	精力蘑菇",
        "材料·食物	Item_Mushroom_B	冰冷蘑菇",
        "材料·食物	Item_Mushroom_C	暖暖蘑菇",
        "材料·食物	Item_Mushroom_E	海拉鲁蘑菇",
        "材料·食物	Item_Mushroom_F	生命松露",
        "材料·食物	Item_Mushroom_F_00	生命松露 x ",
        "GiveItemNumbe",
        "材料·食物	Item_Mushroom_H	酥麻蘑菇",
        "材料·食物	Item_Mushroom_J	潜行蘑菇",
        "材料·食物	Item_Mushroom_L	大剑蘑菇",
        "材料·食物	Item_Mushroom_M	铠甲蘑菇",
        "材料·食物	Item_Mushroom_N	大个生命松露",
        "材料·食物	Item_Mushroom_N_00	大个生命松露 x ",
        "GiveItemNum",
        "材料·食物	Item_Mushroom_O	毅力蘑菇",
        "材料·食物	Item_Ore_A	钻石",
        "材料·食物	Item_Ore_A_00	钻石 x ",
        "GiveItemNumber",
        "材料·食物	Item_Ore_B	红宝石",
        "材料·食物	Item_Ore_C	蓝宝石",
        "材料·食物	Item_Ore_D	黄玉",
        "材料·食物	Item_Ore_E	蛋白石",
        "材料·食物	Item_Ore_F	琥珀",
        "材料·食物	Item_Ore_G	夜光石",
        "材料·食物	Item_Ore_H	岩盐",
        "材料·食物	Item_Ore_I	打火石",
        "材料·食物	Item_Ore_J	星星碎片",
        "材料·食物	Item_PlantGet_A	海拉鲁草",
        "材料·食物	Item_PlantGet_B	生命小萝卜",
        "材料·食物	Item_PlantGet_C	生命大萝卜",
        "材料·食物	Item_PlantGet_E	冰冷香草",
        "材料·食物	Item_PlantGet_F	暖暖香草",
        "材料·食物	Item_PlantGet_G	大剑草",
        "材料·食物	Item_PlantGet_H	铠甲草",
        "材料·食物	Item_PlantGet_I	潜行草",
        "材料·食物	Item_PlantGet_J	静谧公主",
        "材料·食物	Item_PlantGet_L	酥麻香草",
        "材料·食物	Item_PlantGet_M	速速胡萝卜",
        "材料·食物	Item_PlantGet_O	速速紫罗兰",
        "材料·食物	Item_PlantGet_Q	毅力胡萝卜",
        "材料·食物	Item_RoastFish_01	烤鲈鱼",
        "材料·食物	Item_RoastFish_02	烤生命鲈鱼",
        "材料·食物	Item_RoastFish_03	烤鳟鱼",
        "材料·食物	Item_RoastFish_04	烤生命三文鱼",
        "材料·食物	Item_RoastFish_07	烤鲤鱼",
        "材料·食物	Item_RoastFish_09	烤鲷鱼",
        "材料·食物	Item_RoastFish_11	烤生命海螺",
        "材料·食物	Item_RoastFish_13	烤潜行田螺",
        "材料·食物	Item_RoastFish_15	烤螃蟹",
        "材料·食物	Item_Roast_01	烤兽肉",
        "材料·食物	Item_Roast_02	烤禽肉",
        "材料·食物	Item_Roast_03	烤苹果",
        "材料·食物	Item_Roast_04	烤精力蘑菇",
        "材料·食物	Item_Roast_05	烤生命松露",
        "材料·食物	Item_Roast_06	烤海拉鲁蘑菇",
        "材料·食物	Item_Roast_07	烤草莓",
        "材料·食物	Item_Roast_08	烤酥麻水果",
        "材料·食物	Item_Roast_09	烤生命榴莲",
        "材料·食物	Item_Roast_10	烤椰子",
        "材料·食物	Item_Roast_11	烤大剑香蕉",
        "材料·食物	Item_Roast_12	烤冰冷蜜瓜",
        "材料·食物	Item_Roast_13	烤暖暖草果",
        "材料·食物	Item_Roast_15	烤铠甲南瓜",
        "材料·食物	Item_Roast_16	烤速速莲蓬",
        "材料·食物	Item_Roast_18	烤小萝卜",
        "材料·食物	Item_Roast_19	烤大萝卜",
        "材料·食物	Item_Roast_24	烤速速胡萝卜",
        "材料·食物	Item_Roast_27	烤大剑草",
        "材料·食物	Item_Roast_28	烤铠甲草",
        "材料·食物	Item_Roast_31	烤冰冷蘑菇",
        "材料·食物	Item_Roast_32	烤暖暖蘑菇",
        "材料·食物	Item_Roast_33	烤酥麻蘑菇",
        "材料·食物	Item_Roast_36	烤速速蘑菇",
        "材料·食物	Item_Roast_37	烤大剑蘑菇",
        "材料·食物	Item_Roast_38	烤铠甲蘑菇",
        "材料·食物	Item_Roast_39	烤潜行蘑菇",
        "材料·食物	Item_Roast_40	烤高级兽肉",
        "材料·食物	Item_Roast_41	烤高级禽肉",
        "材料·食物	Item_Roast_45	烤顶级兽肉",
        "材料·食物	Item_Roast_46	烤顶级禽肉",
        "材料·食物	Item_Roast_48	烤橡子",
        "材料·食物	Item_Roast_49	烤大个生命松露",
        "材料·食物	Item_Roast_50	烤毅力胡萝卜",
        "材料·食物	Item_Roast_51	烤蛋",
        "材料·食物	Item_Roast_52	烤树果",
        "材料·食物	Item_Roast_53	烤毅力蘑菇"
    };

    public static void SetRupee(ulong v) { Write(GD_RUPEE, BitConverter.GetBytes(v)); }
    public static void SetArrow(int i, ulong v) { Write(GD_POUCH + (ulong)i * GD_STRIDE, BitConverter.GetBytes(v)); }

    public static void LoadGamedata()
    {
        GdReady = false;
        ArrowSlots = new int[0];
        if (ReadU64(GD_RUPEE + 8) != GD_TYPE || ReadU64(GD_POUCH + 8) != GD_TYPE) return;
        if (ReadU64(GD_NAMES + 8) != GD_NAME_TYPE) return;
        float st = ReadF32(GD_STAMINA);
        if (st < 0f || st > 4000f) return;
        var buf = new byte[420 * (int)GD_STRIDE];
        if (!Read(GD_POUCH, buf)) return;
        for (int i = 0; i < 420; i++) PouchValues[i] = BitConverter.ToUInt64(buf, i * (int)GD_STRIDE);
        // 快照武器槽（名字以 Weapon_ 开头），供「武器损坏自动复原」使用
        var wsp = new System.Collections.Generic.List<int>();
        var wnm = new System.Collections.Generic.List<byte[]>();
        var wvl = new System.Collections.Generic.List<ulong>();
        for (int i = 0; i < 420; i++)
        {
            var nb = new byte[60];
            if (!Read(GD_NAMES + (ulong)i * GD_NAME_STRIDE + 0x2C, nb)) continue;
            int endn = 0;
            while (endn < nb.Length && nb[endn] != 0) endn++;
            string nm = System.Text.Encoding.ASCII.GetString(nb, 0, endn);
            if (!nm.StartsWith("Weapon_")) continue;
            wsp.Add(i);
            wnm.Add(nb);
            wvl.Add(PouchValues[i]);
        }
        WeaponSlots = wsp.ToArray();
        WeaponNames = wnm.ToArray();
        WeaponValues = wvl.ToArray();
        GdReady = true;
        // 按存档里的物品顺序，找出箭矢所在的槽位
        string root = Gd.FindSaveRoot();
        int bestScore = -1;
        int[] bestArrows = null;
        string bestSlot = "?";
        for (int sl = 0; sl < 6; sl++)
        {
            string f = Path.Combine(root, sl.ToString(), "game_data.sav");
            if (!File.Exists(f)) continue;
            try
            {
                byte[] d = Gd.ReadSav(f);
                int pj = Gd.FindKey(d, "PorchItem");
                int pv = Gd.FindKey(d, "PorchItem_Value1");
                if (pj < 0 || pv < 0) continue;
                int score = 0;
                var arrows = new System.Collections.Generic.List<int>();
                for (int i = 0; i < 420; i++)
                {
                    uint v = BitConverter.ToUInt32(d, pv + 4 + i * 8);
                    if (v != 0 && (PouchValues[i] & 0xFFFFFFFF) == v) score++;
                    string name = Gd.NameAt(d, pj + i * 128);
                    if (name.EndsWith("Arrow")) arrows.Add(i);
                }
                if (score > bestScore) { bestScore = score; bestArrows = arrows.ToArray(); bestSlot = sl.ToString(); }
            }
            catch { }
        }
        if (bestScore >= 3 && bestArrows != null && bestArrows.Length > 0)
        {
            ArrowSlots = bestArrows;
            GdSlot = bestSlot;
        }
        else
        {
            ArrowSlots = new int[0];  // 探测失败就不要猜槽位（旧版硬编码 9 其实是把弓）
            GdSlot = "?";
        }
    }

    public static IntPtr Handle = IntPtr.Zero;
    public static int Pid;
    public static int Version;
    public static bool Attached;
    public static ulong Pinfo, Player, World;
    static DateTime lastTry = DateTime.MinValue;

    public static bool Read(ulong addr, byte[] buf)
    {
        IntPtr got;
        return Native.ReadProcessMemory(Handle, (IntPtr)(long)addr, buf, (IntPtr)buf.Length, out got);
    }
    public static bool Write(ulong addr, byte[] buf)
    {
        IntPtr put;
        return Native.WriteProcessMemory(Handle, (IntPtr)(long)addr, buf, (IntPtr)buf.Length, out put);
    }
    public static ulong ReadU64(ulong addr)
    {
        var b = new byte[8];
        return Read(addr, b) ? BitConverter.ToUInt64(b, 0) : 0;
    }
    public static uint ReadU32(ulong addr)
    {
        var b = new byte[4];
        return Read(addr, b) ? BitConverter.ToUInt32(b, 0) : 0;
    }
    public static int ReadI32(ulong addr)
    {
        var b = new byte[4];
        return Read(addr, b) ? BitConverter.ToInt32(b, 0) : 0;
    }
    public static float ReadF32(ulong addr)
    {
        var b = new byte[4];
        return Read(addr, b) ? BitConverter.ToSingle(b, 0) : 0f;
    }
    public static void WriteI32(ulong addr, int v) { Write(addr, BitConverter.GetBytes(v)); }
    public static void WriteF32(ulong addr, float v) { Write(addr, BitConverter.GetBytes(v)); }

    public static void Detach()
    {
        if (Handle != IntPtr.Zero) Native.CloseHandle(Handle);
        Handle = IntPtr.Zero;
        Attached = false;
        Version = 0;
        Pinfo = Player = World = 0;
    }

    public static bool TryAttach()
    {
        if (Attached) return true;
        if ((DateTime.Now - lastTry).TotalMilliseconds < 1200) return false;
        lastTry = DateTime.Now;
        var ps = Process.GetProcessesByName("savagewind");
        if (ps.Length == 0) return false;
        var p = ps[0];
        Handle = Native.OpenProcess(0x1F0FFF, false, p.Id);
        if (Handle == IntPtr.Zero) return false;
        Pid = p.Id;
        ulong[] pifs = { PIF_190, PIF_182 };
        ulong[] wms = { WM_190, WM_182 };
        int[] vers = { 190, 182 };
        for (int i = 0; i < 2; i++)
        {
            ulong pinfo = ReadU64(pifs[i]);
            if (pinfo < 0x10000) continue;
            float mx = ReadF32(pinfo + OFF_PIF_MAXHEART);
            float st = ReadF32(pinfo + OFF_PIF_STAMINA_CURMAX);
            float x = ReadF32(pinfo + 0x88), z = ReadF32(pinfo + 0x90);
            if (mx < 2f || mx > 160f) continue;
            if (st < 50f || st > 4000f) continue;
            if (Math.Abs(x) > 20000f || Math.Abs(z) > 20000f) continue;
            ulong player = ReadU64(pinfo + OFF_PIF_PLAYER);
            if (player < 0x10000) continue;
            int life = ReadI32(player + OFF_PL_LIFE);
            int maxlife = ReadI32(player + OFF_PL_MAXLIFE);
            if (life < -1 || life > 200 || maxlife < 0 || maxlife > 200) continue;
            ulong wm = ReadU64(wms[i]);
            if (wm < 0x10000) continue;
            Pinfo = pinfo; Player = player; World = wm; Version = vers[i]; Attached = true;
            LoadGamedata();
            return true;
        }
        Native.CloseHandle(Handle);
        Handle = IntPtr.Zero;
        return false;
    }

    public static float MaxHeart() { return ReadF32(Pinfo + OFF_PIF_MAXHEART); }
    public static void SetMaxHeart(int q)
    {
        WriteF32(Pinfo + OFF_PIF_MAXHEART, q);
        WriteI32(Player + OFF_PL_MAXLIFE, q);
    }
    public static void SetLife(int q) { WriteI32(Player + OFF_PL_LIFE, q); }

    public static bool GetTod(out float tod)
    {
        tod = 0;
        if (World == 0) return false;
        uint n = ReadU32(World + OFF_WM_COUNT);
        if (n == 0) return false;
        ulong mgrs = ReadU64(World + OFF_WM_MANAGERS);
        if (mgrs == 0) return false;
        ulong tm = ReadU64(mgrs);
        if (tm == 0) return false;
        tod = ReadF32(tm + OFF_TOD);
        return true;
    }
    public static void SetTod(float tod)
    {
        if (World == 0) return;
        uint n = ReadU32(World + OFF_WM_COUNT);
        if (n == 0) return;
        ulong mgrs = ReadU64(World + OFF_WM_MANAGERS);
        if (mgrs == 0) return;
        ulong tm = ReadU64(mgrs);
        if (tm == 0) return;
        WriteF32(tm + OFF_TOD, tod);
    }
}

static class Gd
{
    public static uint Crc32(string str)
    {
        uint c = 0xFFFFFFFFu;
        foreach (char ch in str)
        {
            c ^= (byte)ch;
            for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & (uint)(-(int)(c & 1)));
        }
        return ~c;
    }
    public static string FindSaveRoot()
    {
        string a = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "save", "save_0");
        if (Directory.Exists(a)) return a;
        string parent = Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\'));
        if (parent != null)
        {
            string b = Path.Combine(parent, "save", "save_0");
            if (Directory.Exists(b)) return b;
        }
        return a;
    }

    // 游戏运行时会独占存档文件，普通 File.ReadAllBytes/WriteAllBytes 会抛异常被 catch 静默吞掉。
    // 用 FileShare.ReadWrite 打开即可在游戏运行中读写。
    public static byte[] ReadSav(string f)
    {
        using (var fs = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
        {
            var b = new byte[fs.Length];
            int n = 0, r;
            while (n < b.Length && (r = fs.Read(b, n, b.Length - n)) > 0) n += r;
            return b;
        }
    }

    public static void WriteSav(string f, byte[] b)
    {
        using (var fs = new FileStream(f, FileMode.Open, FileAccess.Write, FileShare.ReadWrite))
        {
            fs.Position = 0;
            fs.Write(b, 0, b.Length);
            fs.SetLength(b.Length);
            fs.Flush();
        }
    }

    public static int FindKey(byte[] d, string name)
    {
        uint h = Crc32(name);
        for (int i = 0; i + 4 <= d.Length; i++)
            if (BitConverter.ToUInt32(d, i) == h) return i;
        return -1;
    }
    public static string NameAt(byte[] d, int off)
    {
        var sb = new System.Text.StringBuilder();
        for (int j = 0; j < 16; j++)
        {
            int o = off + 4 + j * 8;
            if (o + 4 > d.Length) break;
            for (int k = 0; k < 4; k++)
            {
                byte b = d[o + k];
                if (b == 0) return sb.ToString();
                sb.Append((char)b);
            }
        }
        return sb.ToString();
    }
}

class CheatRow : Panel
{
    public string Title;
    public string KeyText;
    public bool On;
    public event EventHandler Changed;
    bool hover;

    public CheatRow(string title, string key)
    {
        Title = title;
        KeyText = key;
        Height = 48;
        Dock = DockStyle.Top;
        DoubleBuffered = true;
        Cursor = Cursors.Hand;
        Margin = new Padding(0, 0, 0, 8);
    }

    protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { hover = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseClick(MouseEventArgs e)
    {
        On = !On;
        Invalidate();
        if (Changed != null) Changed(this, EventArgs.Empty);
        base.OnMouseClick(e);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
        g.Clear(hover ? Color.FromArgb(29, 31, 37) : Color.FromArgb(23, 25, 30));
        float s = Ui.S;
        if (On)
        {
            using (var b = new SolidBrush(Color.FromArgb(214, 74, 56)))
                g.FillRectangle(b, 0, 0, (int)(3 * s), Height);
        }
        var box = new Rectangle((int)(15 * s), (int)(14 * s), (int)(19 * s), (int)(19 * s));
        using (var b = new SolidBrush(On ? Color.FromArgb(214, 74, 56) : Color.FromArgb(43, 46, 54)))
        using (var path = RoundRect(box, 4))
            g.FillPath(b, path);
        if (On)
        {
            using (var p = new Pen(Color.FromArgb(255, 245, 240), 2.2f * s))
            {
                g.DrawLine(p, box.Left + 4 * s, box.Top + 10 * s, box.Left + 8 * s, box.Top + 14 * s);
                g.DrawLine(p, box.Left + 8 * s, box.Top + 14 * s, box.Left + 15 * s, box.Top + 4 * s);
            }
        }
        using (var f = new Font("Microsoft YaHei UI", 11f))
        using (var b = new SolidBrush(On ? Color.FromArgb(247, 238, 234) : Color.FromArgb(205, 207, 215)))
            g.DrawString(Title, f, b, new PointF(48 * s, (Height - f.Height) / 2f - 1));
        using (var f = new Font("Consolas", 9.5f, FontStyle.Bold))
        using (var b = new SolidBrush(Color.FromArgb(138, 140, 148)))
        {
            var sz = g.MeasureString(KeyText, f);
            g.DrawString(KeyText, f, b, new PointF(Width - sz.Width - 18 * s, (Height - f.Height) / 2f - 1));
        }
    }

    public static GraphicsPath RoundRect(Rectangle r, int radius)
    {
        var p = new GraphicsPath();
        int d = radius * 2;
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }
}

class MainForm : Form
{
    CheatRow[] rows = new CheatRow[6];
    Label status;
    Panel dot;
    Timer timer;
    int savedHeart;
    bool[] on = new bool[5];

    public MainForm()
    {
        Text = "塞尔达传说：旷野之息 修改器";
        ClientSize = new Size(468, 900);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(17, 18, 22);
        ForeColor = Color.FromArgb(240, 240, 244);
        DoubleBuffered = true;
        AutoScaleMode = AutoScaleMode.None;
        Font = new Font("Microsoft YaHei UI", 9f);

        var table = new TableLayoutPanel();
        table.Dock = DockStyle.Fill;
        table.ColumnCount = 1;
        table.RowCount = 6;
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        table.RowStyles.Add(new RowStyle(SizeType.Absolute, 98f));
        table.RowStyles.Add(new RowStyle(SizeType.Absolute, 400f));
        table.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
        table.RowStyles.Add(new RowStyle(SizeType.Absolute, 0f));  // 时间面板已删除
        table.RowStyles.Add(new RowStyle(SizeType.Absolute, 170f));
        table.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
        table.BackColor = Color.FromArgb(17, 18, 22);

        var header = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(17, 18, 22) };
        header.Paint += delegate(object s, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            float hs = Ui.S;
            using (var b = new SolidBrush(Color.FromArgb(214, 74, 56)))
                g.FillRectangle(b, 0, 0, header.Width, (int)(3 * hs));
            using (var f = new Font("Microsoft YaHei UI", 15.5f, FontStyle.Bold))
            using (var b = new SolidBrush(Color.FromArgb(242, 242, 246)))
                g.DrawString("塞尔达传说：旷野之息", f, b, 20 * hs, 20 * hs);
            using (var f = new Font("Microsoft YaHei UI", 9.5f))
            using (var b = new SolidBrush(Color.FromArgb(214, 120, 100)))
                g.DrawString("修改器", f, b, 21 * hs, 52 * hs);
            using (var f = new Font("Microsoft YaHei UI", 8.5f))
            using (var b = new SolidBrush(Color.FromArgb(146, 148, 156)))
                g.DrawString("Savage Wind Recomp  ·  v1.5", f, b, 92 * hs, 55 * hs);
        };
        table.Controls.Add(header, 0, 0);

        var list = new Panel { Dock = DockStyle.Fill, Padding = new Padding(18, 8, 18, 0), BackColor = Color.FromArgb(17, 18, 22) };
        string[] titles = { "无限生命（锁定满血）", "最大心心（30 颗）", "无限卢比", "无限体力", "武器无限耐久（损坏自动复原）" };
        string[] keys = { "F1", "F2", "F3", "F4", "F5" };
        for (int i = 4; i >= 0; i--)
        {
            var r = new CheatRow(titles[i], keys[i]);
            int idx = i;
            r.Changed += delegate { Toggle(idx); };
            rows[i] = r;
            list.Controls.Add(r);
        }
        table.Controls.Add(list, 0, 1);

        var statusPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(18, 4, 18, 4), BackColor = Color.FromArgb(17, 18, 22) };
        var box = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(27, 29, 35) };
        status = new Label();
        status.AutoSize = false;
        status.Dock = DockStyle.Fill;
        status.TextAlign = ContentAlignment.MiddleLeft;
        status.Padding = new Padding(26, 0, 8, 0);
        status.ForeColor = Color.FromArgb(196, 186, 166);
        status.Font = new Font("Microsoft YaHei UI", 9f);
        status.Text = "等待游戏启动…（请先进入存档）";
        dot = new Panel { Width = 8, Height = 8, BackColor = Color.FromArgb(206, 162, 68), Location = new Point(10, 17) };
        box.Controls.Add(status);
        box.Controls.Add(dot);
        dot.BringToFront();
        statusPanel.Controls.Add(box);
        table.Controls.Add(statusPanel, 0, 2);


        var savePanel = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(17, 18, 22) };
        var saveTitle = new Label { Text = "存档修改（写入存档，回标题画面重新读档后生效）", ForeColor = Color.FromArgb(148, 150, 158), AutoSize = false, Height = 20, Location = new Point(18, 8), Width = 430, BackColor = Color.FromArgb(17, 18, 22) };
        string[] snames = { "卢比 自定量", "箭矢 自定量", "材料 自定量", "耐久 自定量" };
        int[] svals = { 0, 1, 2, 3 };
        int sbw = 99;
        for (int i = 0; i < 4; i++)
        {
            int kind = svals[i];
            var b = new Button();
            b.Text = snames[i];
            b.FlatStyle = FlatStyle.Flat;
            b.BackColor = Color.FromArgb(40, 33, 33);
            b.ForeColor = Color.FromArgb(226, 200, 196);
            b.Size = new Size(sbw, 32);
            b.Location = new Point(18 + i * (sbw + 6), 36);
            b.Font = new Font("Microsoft YaHei UI", 9f);
            b.TabStop = false;
            b.FlatAppearance.BorderSize = 0;
            b.FlatAppearance.MouseOverBackColor = Color.FromArgb(52, 40, 40);
            b.Click += delegate
            {
                int max = kind == 0 ? 999999 : (kind == 3 ? 9999 : 999);
                string q = kind == 0 ? "卢比数量（1-999999）"
                         : kind == 1 ? "箭矢数量（1-999）"
                         : kind == 2 ? "材料数量（1-999）"
                         : "武器耐久（1-9999）";
                int amount = NumberPrompt.Ask("存档修改", q, max, 1, max);
                if (amount > 0) DoSaveEdit(kind, amount);
            };
            savePanel.Controls.Add(b);
        }
        var addBtn = new Button();
        addBtn.Text = "添加物品到背包…";
        addBtn.FlatStyle = FlatStyle.Flat;
        addBtn.BackColor = Color.FromArgb(40, 52, 44);
        addBtn.ForeColor = Color.FromArgb(196, 226, 200);
        addBtn.Size = new Size(272, 34);
        addBtn.Location = new Point(18, 80);
        addBtn.Font = new Font("Microsoft YaHei UI", 9f);
        addBtn.TabStop = false;
        addBtn.FlatAppearance.BorderSize = 0;
        addBtn.FlatAppearance.MouseOverBackColor = Color.FromArgb(52, 68, 56);
        addBtn.Click += delegate
        {
            var pk = new ItemPickerForm(Game.ItemData);
            if (pk.ShowDialog() == DialogResult.OK && pk.Selected.Count > 0)
                DoAddItems(pk.Selected, pk.Count);
        };
        var updBtn = new Button();
        updBtn.Text = "检查更新";
        updBtn.FlatStyle = FlatStyle.Flat;
        updBtn.BackColor = Color.FromArgb(44, 44, 52);
        updBtn.ForeColor = Color.FromArgb(200, 202, 210);
        updBtn.Size = new Size(146, 34);
        updBtn.Location = new Point(302, 80);
        updBtn.Font = new Font("Microsoft YaHei UI", 9f);
        updBtn.TabStop = false;
        updBtn.FlatAppearance.BorderSize = 0;
        updBtn.FlatAppearance.MouseOverBackColor = Color.FromArgb(54, 56, 66);
        updBtn.Click += delegate { CheckUpdate(); };
        savePanel.Controls.Add(updBtn);
        savePanel.Controls.Add(addBtn);
        savePanel.Controls.Add(saveTitle);
        table.Controls.Add(savePanel, 0, 4);

        var tip = new Label();
        tip.Dock = DockStyle.Fill;
        tip.Text = "实时项只改内存，关闭即恢复；存档项会先备份再写入，需重新读档生效。";
        tip.ForeColor = Color.FromArgb(108, 110, 118);
        tip.Font = new Font("Microsoft YaHei UI", 8.5f);
        tip.Padding = new Padding(18, 4, 18, 0);
        table.Controls.Add(tip, 0, 5);

        Controls.Add(table);

        // 交给系统做 DPI 虚拟化缩放（manifest 不再声明 dpiAware），布局与字号比例一致

        timer = new Timer();
        timer.Interval = 40;
        timer.Tick += delegate { Apply(); UpdateStatus(); };
        timer.Start();
    }



    static uint Crc32(string str)
    {
        uint c = 0xFFFFFFFFu;
        foreach (char ch in str)
        {
            c ^= (byte)ch;
            for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & (uint)(-(int)(c & 1)));
        }
        return ~c;
    }

    static int FindKey(byte[] d, string name)
    {
        uint h = Crc32(name);
        for (int i = 0; i + 4 <= d.Length; i++)
            if (BitConverter.ToUInt32(d, i) == h) return i;
        return -1;
    }

    static void PutU32(byte[] d, int off, uint v)
    {
        d[off] = (byte)v; d[off + 1] = (byte)(v >> 8); d[off + 2] = (byte)(v >> 16); d[off + 3] = (byte)(v >> 24);
    }

    static bool SetFlag(byte[] d, string name, uint value)
    {
        int off = FindKey(d, name);
        if (off < 0 || off + 8 > d.Length) return false;
        PutU32(d, off + 4, value);
        return true;
    }

    static bool SetItems(byte[] d, int kind, uint value)
    {
        int pj = FindKey(d, "PorchItem");
        int pv = FindKey(d, "PorchItem_Value1");
        if (pj < 0 || pv < 0) return false;
        for (int i = 0; i < 420; i++)
        {
            int nameOff = pj + i * 128;
            if (nameOff + 128 > d.Length) break;
            string name = "";
            for (int j = 0; j < 16; j++)
            {
                int o = nameOff + 4 + j * 8;
                if (o + 4 > d.Length) break;
                for (int k = 0; k < 4; k++)
                {
                    byte b = d[o + k];
                    if (b == 0) { j = 99; break; }
                    name += (char)b;
                }
            }
            if (name.Length == 0) continue;
            bool arrow = name.EndsWith("Arrow");
            bool weapon = name.StartsWith("Weapon_");
            bool armor = name.StartsWith("Armor_");
            bool apply = false;
            if (kind == 1) apply = arrow;
            else if (kind == 2) apply = !arrow && !weapon && !armor;
            else if (kind == 3) apply = weapon;
            if (!apply) continue;
            int vo = pv + 4 + i * 8;
            if (vo + 4 > d.Length) break;
            PutU32(d, vo, value);
        }
        return true;
    }

    void DoSaveEdit(int kind, int amount)
    {
        string root = Gd.FindSaveRoot();
        if (!Directory.Exists(root))
        {
            MessageBox.Show("找不到存档目录：\n" + root + "\n\n请把修改器放在 savagewind.exe 旁边。", "存档修改");
            return;
        }
        int done = 0;
        for (int slot = 0; slot < 6; slot++)
        {
            string f = Path.Combine(root, slot.ToString(), "game_data.sav");
            if (!File.Exists(f)) continue;
            string bak = f + ".bak";
            try
            {
                if (!File.Exists(bak)) File.Copy(f, bak);
                byte[] data = Gd.ReadSav(f);
                bool ok;
                uint v = (uint)Math.Max(1, Math.Min(amount, kind == 0 ? 999999 : (kind == 3 ? 9999 : 999)));
                if (kind == 0) ok = SetFlag(data, "CurrentRupee", v);
                else if (kind == 1) ok = SetItems(data, 1, v);
                else if (kind == 2) ok = SetItems(data, 2, v);
                else ok = SetItems(data, 3, v);
                if (ok)
                {
                    Gd.WriteSav(f, data);
                    done++;
                }
            }
            catch { }
        }
        MessageBox.Show("已写入 " + done + " 个存档槽。\n\n回到标题画面重新读档（继续游戏）后生效。\n原文件已备份为 game_data.sav.bak。",
                        "存档修改");
    }


    // 更新地址：优先读修改器同级目录的 update.txt（第一行有效地址），否则用本机更新站
    static string UpdateBaseUrl()
    {
        try
        {
            string f = Path.Combine(Path.GetDirectoryName(System.Windows.Forms.Application.ExecutablePath), "update.txt");
            if (File.Exists(f))
            {
                foreach (var line in File.ReadAllLines(f))
                {
                    string s = line.Trim();
                    if (s.Length == 0 || s.StartsWith("#")) continue;
                    if (!s.StartsWith("http")) continue;
                    if (!s.EndsWith("/")) s += "/";
                    return s;
                }
            }
        }
        catch { }
        return "http://127.0.0.1:8080/";
    }

    static string JsonField(string json, string key)
    {
        var m = System.Text.RegularExpressions.Regex.Match(json, "\"" + key + "\"\\s*:\\s*\"([^\"]*)\"");
        return m.Success ? m.Groups[1].Value : "";
    }

    static string Sha256File(string path)
    {
        using (var fs = File.OpenRead(path))
        using (var sha = System.Security.Cryptography.SHA256.Create())
        {
            var h = sha.ComputeHash(fs);
            var sb = new System.Text.StringBuilder();
            foreach (var b in h) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }
    }

    void CheckUpdate()
    {
        try
        {
            string json;
            using (var wc = new System.Net.WebClient())
            {
                wc.Encoding = System.Text.Encoding.UTF8;
                json = wc.DownloadString(UpdateBaseUrl() + "version.json");
            }
            string ver = JsonField(json, "version");
            string hash = JsonField(json, "sha256").ToLower();
            string note = JsonField(json, "note");
            string builtAt = JsonField(json, "builtAt");
            string self = System.Windows.Forms.Application.ExecutablePath;
            string cur = Sha256File(self).ToLower();

            if (cur == hash)
            {
                MessageBox.Show("已是最新版本。\n\n版本：" + ver + "\n构建：" + builtAt + "\n说明：" + note, "检查更新");
                return;
            }
            if (MessageBox.Show("发现新版本 " + ver + "\n\n说明：" + note + "\n构建：" + builtAt +
                                "\n\n现在更新吗？修改器会自动下载、替换并重启。",
                                "检查更新", MessageBoxButtons.YesNo) != DialogResult.Yes) return;

            string tmp = Path.Combine(Path.GetTempPath(), "SavageWindTrainer_new.exe");
            using (var wc = new System.Net.WebClient())
                wc.DownloadFile(UpdateBaseUrl() + "SavageWindTrainer.exe", tmp);

            if (Sha256File(tmp).ToLower() != hash)
            {
                MessageBox.Show("下载文件校验失败，已取消更新。", "检查更新");
                return;
            }

            string bak = self + ".old";
            try { if (File.Exists(bak)) File.Delete(bak); File.Copy(self, bak); } catch { }

            var psi = new ProcessStartInfo("cmd.exe",
                "/c ping 127.0.0.1 -n 3 >nul & move /y \"" + tmp + "\" \"" + self + "\" & start \"\" \"" + self + "\"");
            psi.WindowStyle = ProcessWindowStyle.Hidden;
            psi.CreateNoWindow = true;
            Process.Start(psi);
            Application.Exit();
        }
        catch (Exception ex)
        {
            MessageBox.Show("检查更新失败：\n" + ex.Message +
                            "\n\n请先启动更新站：双击「修改器\\更新站\\启动更新站.bat」", "检查更新");
        }
    }

    void DoAddItems(System.Collections.Generic.List<string> names, int count)
    {
        string root = Gd.FindSaveRoot();
        if (!Directory.Exists(root))
        {
            MessageBox.Show("找不到存档目录：\n" + root, "添加物品");
            return;
        }
        int done = 0;
        var okSlots = new System.Collections.Generic.List<int>();
        var failSlots = new System.Collections.Generic.List<int>();
        for (int slot = 0; slot < 6; slot++)
        {
            string f = Path.Combine(root, slot.ToString(), "game_data.sav");
            if (!File.Exists(f)) continue;
            string bak = f + ".bak";
            try
            {
                if (!File.Exists(bak)) File.Copy(f, bak);
                byte[] d = Gd.ReadSav(f);
                int pj = Gd.FindKey(d, "PorchItem");
                int pv = Gd.FindKey(d, "PorchItem_Value1");
                if (pj < 0 || pv < 0) continue;
                bool changed = false;
                foreach (var name in names)
                {
                    bool added = false;
                    int empty = -1;
                    for (int i = 0; i < 420; i++)
                    {
                        string n0 = Gd.NameAt(d, pj + i * 128);
                        if (n0.Length == 0) { if (empty < 0) empty = i; continue; }
                        if (n0 == name)
                        {
                            uint v = BitConverter.ToUInt32(d, pv + 4 + i * 8);
                            uint nv = name.StartsWith("Weapon_") ? 9999u : Math.Min(999u, v + (uint)count);
                            for (int k = 0; k < 4; k++) d[pv + 4 + i * 8 + k] = (byte)(nv >> (8 * k));
                            added = true;
                            changed = true;
                            break;
                        }
                    }
                    if (!added && empty >= 0)
                    {
                        for (int j = 0; j < 16; j++)
                        {
                            int o = pj + empty * 128 + 4 + j * 8;
                            for (int k = 0; k < 4; k++)
                            {
                                int idx = j * 4 + k;
                                d[o + k] = idx < name.Length ? (byte)name[idx] : (byte)0;
                            }
                        }
                        uint cv = name.StartsWith("Weapon_") ? 9999u : (uint)Math.Min(999, count);
                        for (int k = 0; k < 4; k++) d[pv + 4 + empty * 8 + k] = (byte)(cv >> (8 * k));
                        changed = true;
                    }
                }
                if (changed)
                {
                    Gd.WriteSav(f, d);
                    done++;
                    okSlots.Add(slot);
                }
            }
            catch { failSlots.Add(slot); }
        }
        string slotInfo = "\n成功: " + (okSlots.Count > 0 ? string.Join(",", okSlots.ToArray()) : "无");
        if (failSlots.Count > 0)
            slotInfo += "\n失败(被占用): " + string.Join(",", failSlots.ToArray()) + " —— 关掉游戏再点一次";
        MessageBox.Show("已写入 " + done + " 个存档槽，共 " + names.Count + " 种物品。" + slotInfo +
                        "\n\n回到标题画面重新读档（继续游戏）后生效。", "添加物品");
    }

    void SetRowOn(int i, bool v)
    {
        on[i] = v;
        rows[i].On = v;
        rows[i].Invalidate();
    }

    void Toggle(int i)
    {
        bool v = !on[i];
        on[i] = v;
        rows[i].On = v;
        if (i == 0)
        {
            if (v)
            {
                if (Game.Attached)
                {
                    int cur = (int)(Game.MaxHeart() + 0.5f);
                    savedHeart = cur >= 4 ? cur : 12;
                    Game.SetMaxHeart(Game.MAX_HEART_QUARTERS);
                    Game.SetLife(Game.MAX_HEART_QUARTERS);
                }
                else savedHeart = 12;
                SetRowOn(1, true);
            }
            else
            {
                int back = savedHeart > 0 ? savedHeart : 12;
                if (Game.Attached) { Game.SetMaxHeart(back); Game.SetLife(back); }
                SetRowOn(1, false);
            }
        }
        else if (i == 1)
        {
            if (v)
            {
                if (Game.Attached)
                {
                    int cur = (int)(Game.MaxHeart() + 0.5f);
                    if (cur >= 4 && cur <= Game.MAX_HEART_QUARTERS) savedHeart = cur;
                    Game.SetMaxHeart(Game.MAX_HEART_QUARTERS);
                    Game.SetLife(Game.MAX_HEART_QUARTERS);
                }
            }
            else if (!on[0])
            {
                int back = savedHeart > 0 ? savedHeart : 12;
                if (Game.Attached) { Game.SetMaxHeart(back); Game.SetLife(back); }
            }
        }
        else if (i == 2)
        {
            // 无限卢比由 Apply 每 tick 写入，这里无需额外动作
        }
    }

    void Apply()
    {
        if (!Game.Attached && !Game.TryAttach()) return;
        try
        {
            var p = Process.GetProcessById(Game.Pid);
            if (p.HasExited) { Game.Detach(); return; }
        }
        catch { Game.Detach(); return; }

        ulong pl = Game.ReadU64(Game.Pinfo + 0x60);
        if (pl > 0x10000) Game.Player = pl;

        if (on[0] || on[1])
        {
            Game.SetMaxHeart(Game.MAX_HEART_QUARTERS);
            Game.SetLife(Game.MAX_HEART_QUARTERS);
        }
        if (on[2] && Game.GdReady) Game.SetRupee(999999);
        if (on[4] && Game.GdReady)
        {
            for (int k = 0; k < Game.WeaponSlots.Length; k++)
            {
                int idx = Game.WeaponSlots[k];
                var nb = new byte[60];
                if (!Game.Read(Game.GD_NAMES + (ulong)idx * Game.GD_NAME_STRIDE + 0x2C, nb)) continue;
                bool same = true;
                for (int b = 0; b < 60; b++)
                    if (nb[b] != Game.WeaponNames[k][b]) { same = false; break; }
                if (!same)
                {
                    Game.Write(Game.GD_NAMES + (ulong)idx * Game.GD_NAME_STRIDE + 0x2C, Game.WeaponNames[k]);
                    Game.Write(Game.GD_POUCH + (ulong)idx * Game.GD_STRIDE, BitConverter.GetBytes(Game.WeaponValues[k]));
                }
                else
                {
                    // 每 tick 把耐久补满：剑/弓/盾/枪共用这个字段
                    // （原来只在名字变化时还原，所以弓的耐久会一直掉）
                    Game.Write(Game.GD_POUCH + (ulong)idx * Game.GD_STRIDE, BitConverter.GetBytes(9999UL));
                }
            }
        }
        if (on[3] && Game.Attached && Game.Pinfo != 0)
        {
            // 真实当前体力 = PlayerInfo + 0xA4，体力上限 = PlayerInfo + 0xA8（实测冲刺时 0xA4 下降、0xA8 恒为 1000）
            float smax = Game.ReadF32(Game.Pinfo + 0xA8);
            if (smax < 100f || smax > 4000f) smax = 1000f;
            Game.WriteF32(Game.Pinfo + 0xA4, smax);
        }
    }
    void UpdateStatus()
    {
        if (Game.Attached)
        {
            status.Text = "已连接 savagewind.exe  ·  游戏版本 " + (Game.Version == 190 ? "1.9.0" : "1.8.2") + "  ·  PID " + Game.Pid;
            status.ForeColor = Color.FromArgb(198, 206, 202);
            if (dot != null) dot.BackColor = Color.FromArgb(76, 199, 118);
        }
        else
        {
            status.Text = "等待游戏启动…（请先进入存档）";
            status.ForeColor = Color.FromArgb(196, 186, 166);
            if (dot != null) dot.BackColor = Color.FromArgb(206, 162, 68);
        }
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        Native.RegisterHotKey(Handle, 1, 0, 0x70); // F1
        Native.RegisterHotKey(Handle, 2, 0, 0x71); // F2
        Native.RegisterHotKey(Handle, 3, 0, 0x72); // F3 无限卢比
        Native.RegisterHotKey(Handle, 4, 0, 0x73); // F4 无限体力
        Native.RegisterHotKey(Handle, 5, 0, 0x74); // F5 武器耐久
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x0312)
        {
            int id = m.WParam.ToInt32();
            if (id >= 1 && id <= 5) Toggle(id - 1);
        }
        base.WndProc(ref m);
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        Game.Detach();
        base.OnFormClosed(e);
    }
}

static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.Run(new MainForm());
    }
}


// 通用数字输入弹窗：用于「存档修改」按自定义数量写入
class NumberPrompt : Form
{
    NumericUpDown num;

    public static int Ask(string title, string label, int value, int min, int max)
    {
        using (var f = new NumberPrompt())
        {
            f.Text = title;
            f.Setup(label, value, min, max);
            return f.ShowDialog() == DialogResult.OK ? (int)f.num.Value : -1;
        }
    }

    void Setup(string label, int value, int min, int max)
    {
        ClientSize = new Size(380, 160);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(23, 25, 30);
        ForeColor = Color.FromArgb(230, 232, 238);
        Font = new Font("Microsoft YaHei UI", 9f);

        var lbl = new Label { Text = label, Left = 20, Top = 18, Width = 340, ForeColor = Color.FromArgb(160, 162, 170) };
        num = new NumericUpDown();
        num.Left = 20;
        num.Top = 46;
        num.Width = 170;
        num.Minimum = min;
        num.Maximum = max;
        num.Value = Math.Max(min, Math.Min(max, value));
        num.Font = new Font("Microsoft YaHei UI", 12f);

        var ok = new Button();
        ok.Text = "写入";
        ok.Left = 130;
        ok.Top = 106;
        ok.Width = 105;
        ok.Height = 34;
        ok.FlatStyle = FlatStyle.Flat;
        ok.BackColor = Color.FromArgb(214, 74, 56);
        ok.ForeColor = Color.White;
        ok.FlatAppearance.BorderSize = 0;
        ok.Click += delegate { DialogResult = DialogResult.OK; Close(); };

        var cancel = new Button();
        cancel.Text = "取消";
        cancel.Left = 246;
        cancel.Top = 106;
        cancel.Width = 105;
        cancel.Height = 34;
        cancel.FlatStyle = FlatStyle.Flat;
        cancel.BackColor = Color.FromArgb(40, 42, 50);
        cancel.ForeColor = Color.FromArgb(210, 212, 220);
        cancel.FlatAppearance.BorderSize = 0;
        cancel.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };

        Controls.Add(lbl);
        Controls.Add(num);
        Controls.Add(ok);
        Controls.Add(cancel);
        AcceptButton = ok;
        CancelButton = cancel;
        ActiveControl = num;
    }
}

class ItemPickerForm : Form
{
    public System.Collections.Generic.List<string> Selected = new System.Collections.Generic.List<string>();
    public int Count = 999;
    ComboBox comboCat;
    TextBox txtSearch;
    CheckedListBox list;
    CheckBox chkRaw;
    string[][] data;
    System.Collections.Generic.List<int> shown = new System.Collections.Generic.List<int>();

    public ItemPickerForm(string[] raw)
    {
        Text = "添加物品到背包（可多选）";
        ClientSize = new Size(760, 560);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(23, 25, 30);
        ForeColor = Color.FromArgb(230, 232, 238);
        Font = new Font("Microsoft YaHei UI", 9f);

        var parsed = new System.Collections.Generic.List<string[]>();
        int badCount = 0;
        foreach (var line in raw)
        {
            var parts = line.Split('\t');
            if (parts.Length < 3) { badCount++; continue; }
            string cat = parts[0].Trim();
            string id = parts[1].Trim();
            string cn = parts[2].Trim();
            if (cat.Length == 0 || id.Length == 0) { badCount++; continue; }
            bool valid = true;
            foreach (char c in id)
                if (!(char.IsLetterOrDigit(c) || c == '_')) { valid = false; break; }
            if (!valid) { badCount++; continue; }
            var sbcn = new System.Text.StringBuilder();
            foreach (char c in cn) if (!char.IsControl(c)) sbcn.Append(c);
            cn = sbcn.ToString().Trim();
            bool hasCjk = false;
            foreach (char c in cn) if (c >= 0x4E00 && c <= 0x9FFF) { hasCjk = true; break; }
            if (!hasCjk) cn = "";
            parsed.Add(new string[] { cat, id, cn });
        }
        data = parsed.ToArray();

        var lblCat = new Label { Text = "分类", Left = 16, Top = 10, Width = 50, ForeColor = Color.FromArgb(150, 152, 160) };
        comboCat = new ComboBox();
        comboCat.Left = 16; comboCat.Top = 30; comboCat.Width = 170;
        comboCat.DropDownStyle = ComboBoxStyle.DropDownList;
        comboCat.MaxDropDownItems = 16;

        var lblSearch = new Label { Text = "搜索", Left = 200, Top = 10, Width = 50, ForeColor = Color.FromArgb(150, 152, 160) };
        txtSearch = new TextBox();
        txtSearch.Left = 200; txtSearch.Top = 30; txtSearch.Width = 250;
        txtSearch.BackColor = Color.FromArgb(35, 37, 44);
        txtSearch.ForeColor = Color.FromArgb(230, 232, 238);
        txtSearch.BorderStyle = BorderStyle.FixedSingle;
        txtSearch.TextChanged += delegate { FillList(); };

        chkRaw = new CheckBox();
        chkRaw.Text = "显示未翻译";
        chkRaw.Left = 466; chkRaw.Top = 31; chkRaw.Width = 120; chkRaw.Height = 22;
        chkRaw.ForeColor = Color.FromArgb(170, 172, 180);
        chkRaw.CheckedChanged += delegate { FillList(); };

        list = new CheckedListBox();
        list.Left = 16; list.Top = 62; list.Width = 728; list.Height = 380;
        list.CheckOnClick = true;
        list.BackColor = Color.FromArgb(30, 32, 38);
        list.ForeColor = Color.FromArgb(228, 230, 236);
        list.BorderStyle = BorderStyle.FixedSingle;
        list.Font = new Font("Microsoft YaHei UI", 9f);

        var btnAll = new Button();
        btnAll.Text = "全选当前列表";
        btnAll.Left = 16; btnAll.Top = 452; btnAll.Width = 110; btnAll.Height = 30;
        btnAll.FlatStyle = FlatStyle.Flat;
        btnAll.BackColor = Color.FromArgb(40, 42, 50);
        btnAll.ForeColor = Color.FromArgb(210, 212, 220);
        btnAll.FlatAppearance.BorderSize = 0;
        btnAll.Click += delegate
        {
            for (int i = 0; i < list.Items.Count; i++) list.SetItemChecked(i, true);
        };

        var btnNone = new Button();
        btnNone.Text = "全不选";
        btnNone.Left = 132; btnNone.Top = 452; btnNone.Width = 90; btnNone.Height = 30;
        btnNone.FlatStyle = FlatStyle.Flat;
        btnNone.BackColor = Color.FromArgb(40, 42, 50);
        btnNone.ForeColor = Color.FromArgb(210, 212, 220);
        btnNone.FlatAppearance.BorderSize = 0;
        btnNone.Click += delegate
        {
            for (int i = 0; i < list.Items.Count; i++) list.SetItemChecked(i, false);
        };

        var lblNum = new Label { Text = "数量", Left = 240, Top = 458, Width = 40, ForeColor = Color.FromArgb(150, 152, 160) };
        var num = new NumericUpDown();
        num.Left = 282; num.Top = 456; num.Width = 80;
        num.Minimum = 1; num.Maximum = 999; num.Value = 999;

        var ok = new Button();
        ok.Text = "写入存档";
        ok.Left = 520; ok.Top = 452; ok.Width = 110; ok.Height = 32;
        ok.FlatStyle = FlatStyle.Flat;
        ok.BackColor = Color.FromArgb(214, 74, 56);
        ok.ForeColor = Color.White;
        ok.FlatAppearance.BorderSize = 0;

        var cancel = new Button();
        cancel.Text = "取消";
        cancel.Left = 640; cancel.Top = 452; cancel.Width = 104; cancel.Height = 32;
        cancel.FlatStyle = FlatStyle.Flat;
        cancel.BackColor = Color.FromArgb(40, 42, 50);
        cancel.ForeColor = Color.FromArgb(210, 212, 220);
        cancel.FlatAppearance.BorderSize = 0;

        var tip = new Label();
        tip.Text = "勾选想要的物品（可多选），一次写入。武器写耐久 9999，其它写数量。写入后回标题重新读档生效。已过滤 " + badCount + " 条残缺数据。";
        tip.Left = 16; tip.Top = 494; tip.Width = 728; tip.Height = 40;
        tip.ForeColor = Color.FromArgb(150, 152, 160);

        var cats = new System.Collections.Generic.List<string>();
        cats.Add("全部");
        foreach (var d in data)
            if (!cats.Contains(d[0])) cats.Add(d[0]);
        comboCat.Items.AddRange(cats.ToArray());
        comboCat.SelectedIndexChanged += delegate { FillList(); };

        ok.Click += delegate
        {
            Selected.Clear();
            foreach (var item in list.CheckedItems)
            {
                string s = item as string;
                if (s == null) continue;
                int p = s.LastIndexOf('（');
                if (p > 0 && s.EndsWith("）")) Selected.Add(s.Substring(p + 1, s.Length - p - 2));
            }
            Count = (int)num.Value;
            DialogResult = DialogResult.OK;
        };
        cancel.Click += delegate { DialogResult = DialogResult.Cancel; };

        Controls.Add(lblCat); Controls.Add(comboCat);
        Controls.Add(lblSearch); Controls.Add(txtSearch);
        Controls.Add(chkRaw); Controls.Add(list);
        Controls.Add(btnAll); Controls.Add(btnNone);
        Controls.Add(lblNum); Controls.Add(num);
        Controls.Add(ok); Controls.Add(cancel); Controls.Add(tip);

        if (comboCat.Items.Count > 0) comboCat.SelectedIndex = 0;
    }

    void FillList()
    {
        string cat = comboCat.SelectedItem as string;
        string kw = (txtSearch.Text ?? "").Trim();
        list.Items.Clear();
        shown.Clear();
        foreach (var d in data)
        {
            if (cat != "全部" && d[0] != cat) continue;
            bool hasCn = d[2].Length > 0;
            if (!hasCn && !chkRaw.Checked) continue;
            string disp = hasCn ? (d[2] + "（" + d[1] + "）") : ("未翻译（" + d[1] + "）");
            if (kw.Length > 0 && disp.IndexOf(kw, StringComparison.OrdinalIgnoreCase) < 0) continue;
            list.Items.Add(disp);
        }
    }
}
